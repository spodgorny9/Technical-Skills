--Written and created by Slater Podgorny
--Reviewed by: Sasha Shadrina and Keanan Anderson
--Originally Written: April 2021
--INFO 3240 Course Project Phase 2
--
------	CREATE DATABASE	-----
--
--Check if database exists 
IF NOT EXISTS(SELECT * FROM sys.databases
	WHERE NAME = N'SkiCorporation')
	CREATE DATABASE SkiCorporation
GO
USE SkiCorporation
--
--Set file path
DECLARE @data_path NVARCHAR(256);
SELECT @data_path = 'C:\Users\slats\Desktop\INFO 3240\DB Builds\SkiCorp\Build SkiCorp\';
--
--Check if tables exist and remove if they do
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'CustomerHistory'
       )
	DROP TABLE CustomerHistory;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'RegionAccommodation'
       )
	DROP TABLE RegionAccommodation;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'ResortPass'
       )
	DROP TABLE ResortPass;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'PassHistory'
       )
	DROP TABLE PassHistory;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Resort'
       )
	DROP TABLE Resort;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Pass'
       )
	DROP TABLE Pass;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Accommodation'
       )
	DROP TABLE Accommodation;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Customer'
       )
	DROP TABLE Customer;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'States'
       )
	DROP TABLE States;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Region'
       )
	DROP TABLE Region;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'PassType'
       )
	DROP TABLE PassType;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'AccommodationType'
       )
	DROP TABLE AccommodationType;
--
-----	CREATE TABLES	------
--
CREATE TABLE AccommodationType
	(TypeID					INT CONSTRAINT pk_type_id PRIMARY KEY,
	TypeName				NVARCHAR(15) CONSTRAINT nn_accomm_type NOT NULL,
	TypeDescription			NVARCHAR(150)
	);
--
CREATE TABLE PassType
	(PassTypeID				INT CONSTRAINT pk_pass_type_id PRIMARY KEY,
	TypeCategory			NVARCHAR(25) CONSTRAINT nn_pass_type NOT NULL,
	);
--
CREATE TABLE Region
	(RegionID				INT CONSTRAINT pk_region_id PRIMARY KEY,
	RegionName				NVARCHAR(25) CONSTRAINT nn_region_name NOT NULL,
	RegionSize				NUMERIC(18,2),
	RegionState				NVARCHAR(2)
	);
--
CREATE TABLE States
	(StateID				NVARCHAR(2),
	StateName				NVARCHAR(20),
	CONSTRAINT pk_states PRIMARY KEY (StateID)
	); 
--
CREATE TABLE Customer
	(CustomerID				INT CONSTRAINT pk_cust_id PRIMARY KEY,
	CustomerFirstName		NVARCHAR(25) CONSTRAINT nn_cust_fname NOT NULL,
	CustomerLastName		NVARCHAR(40) CONSTRAINT nn_cust_lname NOT NULL,
	CustomerEmail			NVARCHAR (50) CONSTRAINT nn_cust_email NOT NULL, 
	CustomerDOB				DATE CONSTRAINT nn_cust_dob NOT NULL,
	CustomerAddress			NVARCHAR (35) CONSTRAINT nn_cust_address NOT NULL, 
	CustomerCity			NVARCHAR (20) CONSTRAINT nn_cust_city NOT NULL,
	CustomerState			NVARCHAR (2) CONSTRAINT fk_customer FOREIGN KEY
		REFERENCES States(StateID),
	CustomerZipCode			NVARCHAR(10) CONSTRAINT nn_cust_zip NOT NULL,
	CustomerCountry			NVARCHAR (20) CONSTRAINT nn_cust_country NOT NULL,
	CustomerPhoto			IMAGE
	);
--
CREATE TABLE Accommodation
	(AccommodationID		INT CONSTRAINT pk_accomm_id PRIMARY KEY,
	TypeID					INT CONSTRAINT fk_type_id FOREIGN KEY
					REFERENCES AccommodationType(TypeID),
	AccommodationName		NVARCHAR(25) CONSTRAINT nn_accomm_name NOT NULL,
	AccommodationAddress	NVARCHAR(35) CONSTRAINT nn_accomm_address NOT NULL,
	AccommodationCity		NVARCHAR(20) CONSTRAINT nn_accomm_city NOT NULL, 
	AccommodationState		NVARCHAR(2) CONSTRAINT nn_accomm_state NOT NULL,
	AccommodationZipCode	NVARCHAR(10) CONSTRAINT nn_accomm_zip NOT NULL,
	AccommodationCountry	NVARCHAR(20) CONSTRAINT nn_accomm_country NOT NULL
	);
--
CREATE TABLE Pass
	(PassID					INT CONSTRAINT pk_pass_id PRIMARY KEY,
	PassTypeID				INT CONSTRAINT fk_pass_type_id FOREIGN KEY
					REFERENCES PassType(PassTypeID),
	CustomerID				INT CONSTRAINT fk_cust_id FOREIGN KEY
					REFERENCES Customer(CustomerID),
	PassName				NVARCHAR(15) CONSTRAINT nn_pass_name NOT NULL, 
	PassActivationDate		DATE CONSTRAINT nn_pass_activ_date NOT NULL, 
	PassCost				MONEY CONSTRAINT nn_pass_cost NOT NULL
	); 
--
CREATE TABLE Resort 
	(ResortID				INT CONSTRAINT pk_resort_id PRIMARY KEY,
	RegionID				INT CONSTRAINT fk_region_id FOREIGN KEY
					REFERENCES Region(RegionID),
	ResortName				NVARCHAR(35) CONSTRAINT nn_resort_name NOT NULL, 
	ResortAvgAnnualSnowfall	INT CONSTRAINT nn_snowfall NOT NULL,
	ResortSize				INT CONSTRAINT nn_res_size NOT NULL, 
	NumberOfLifts			INT, 
	ResortLogo				IMAGE,
	ResortWebsite			NVARCHAR(MAX)
	); 
--
CREATE TABLE ResortPass
	(ResortID				INT,
	PassID					INT,
	PassUsageDate			DATE CONSTRAINT nn_use_date NOT NULL,
	PassStatus				NVARCHAR(5) CONSTRAINT nn_pass_status NOT NULL,
	CONSTRAINT pk_resort_pass PRIMARY KEY (ResortID, PassID),
	CONSTRAINT fk_resort_id FOREIGN KEY(ResortID)
					REFERENCES Resort(ResortID),
	CONSTRAINT fk_pass_id FOREIGN KEY(PassID) 
					REFERENCES Pass(PassID)
	);
--
CREATE TABLE RegionAccommodation 
	(AccommodationID		INT,
	RegionID				INT,
	AccommodationCapacity	INT CONSTRAINT ck_accomm_cap CHECK (AccommodationCapacity>0),
	AccommodationVacancy	NVARCHAR(5),
	CONSTRAINT pk_region_accommodation PRIMARY KEY(AccommodationID, RegionID),
	CONSTRAINT fk_accomm_id FOREIGN KEY(AccommodationID)
					REFERENCES Accommodation(AccommodationID),
	 CONSTRAINT fk_accomm_region_id FOREIGN KEY(RegionID)
					REFERENCES Region(RegionID)
	); 
--
CREATE TABLE CustomerHistory
	(VisitID				INT CONSTRAINT pk_visit_id PRIMARY KEY,
	ResortID				INT CONSTRAINT fk_hist_resort_id FOREIGN KEY
					REFERENCES Resort(ResortID),
	CustomerID				INT CONSTRAINT fk_hist_cust_id FOREIGN KEY
					REFERENCES Customer(CustomerID),
	AttendanceDate			DATE,
	AttendanceDuration		INT CONSTRAINT ck_attendance_dur CHECK(AttendanceDuration>0)
	); 
--
-----	Insert Data into Tables		----- 
--
EXECUTE (N'BULK INSERT AccommodationType FROM ''' + @data_path + N'ACCOMMODATION_TYPE.csv''
WITH (
	FIRSTROW=2, 
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT PassType FROM ''' + @data_path + N'PassType.csv''
WITH (
	FIRSTROW=2, 
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Region FROM ''' + @data_path + N'REGION.csv''
WITH (
	FIRSTROW=2, 
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT States FROM ''' + @data_path + N'STATES.csv''
WITH (
	FIRSTROW=2, 
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Customer FROM ''' + @data_path + N'CUSTOMER.csv''
WITH (
	FIRSTROW=2, 
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Accommodation FROM ''' + @data_path + N'ACCOMMODATION.csv''
WITH (
	FIRSTROW=2, 
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Pass FROM ''' + @data_path + N'PASS.csv''
WITH (
	FIRSTROW=2, 
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Resort FROM ''' + @data_path + N'RESORT.csv''
WITH (
	FIRSTROW=2, 
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT ResortPass FROM ''' + @data_path + N'RESORT_PASS.csv''
WITH (
	FIRSTROW=2, 
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT RegionAccommodation FROM ''' + @data_path + N'REGION_ACCOMMODATION.csv''
WITH (
	FIRSTROW=2, 
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT CustomerHistory FROM ''' + @data_path + N'CUSTOMER_HISTORY.csv''
WITH (
	FIRSTROW=2, 
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
-- List table names and row counts for confirmation
--
GO
SET NOCOUNT ON
SELECT 'Accommodation' AS "Table",	COUNT(*) AS "Rows"	FROM Accommodation			UNION
SELECT 'AccommodationType',			COUNT(*)			FROM AccommodationType		UNION
SELECT 'States',					COUNT(*)			FROM States					UNION
SELECT 'Customer',					COUNT(*)			FROM Customer				UNION
SELECT 'CustomerHistory',			COUNT(*)			FROM CustomerHistory		UNION
SELECT 'Pass',						COUNT(*)			FROM Pass					UNION
SELECT 'PassType',					COUNT(*)			FROM PassType				UNION
SELECT 'Region',					COUNT(*)			FROM Region					UNION
SELECT 'RegionAccommodation',		COUNT(*)			FROM RegionAccommodation	UNION
SELECT 'Resort',					COUNT(*)			FROM Resort					UNION
SELECT 'ResortPass',				COUNT(*)			FROM ResortPass
ORDER BY 1;
SET NOCOUNT OFF
GO

