USE SkiCorporation 
GO
--Create SearchResort view for search form
IF EXISTS (SELECT * FROM sys.views WHERE name=N'SearchResorts') 
	DROP VIEW SearchResorts
GO
CREATE VIEW SearchResorts 
	AS SELECT Resort.ResortID, Region.RegionName, Resort.ResortName, Resort.ResortAvgAnnualSnowfall, Resort.ResortSize, Resort.NumberOfLifts, Resort.ResortWebsite
	FROM Resort
	INNER JOIN Region 
	ON Resort.RegionID = Region.RegionID;
GO
--
--Create NumVisitors view for ResortVisitors subform
IF EXISTS (SELECT * FROM sys.views WHERE name=N'NumVisitors') 
	DROP VIEW NumVisitors
GO
CREATE VIEW NumVisitors
	AS SELECT Resort.ResortName, COUNT(VisitID) AS "NumVisitors"
	FROM Resort
	INNER JOIN CustomerHistory
	ON Resort.ResortID = CustomerHistory.ResortID
	GROUP BY Resort.ResortName; 
GO
--
--Create AvgNumVisitors for ResortVisitors Subform
IF EXISTS (SELECT * FROM sys.views WHERE name=N'AvgNumVisitors') 
	DROP VIEW AvgNumVisitors
GO
CREATE VIEW AvgNumVisitors
AS SELECT AVG(NumVisitors) AS "IndustryAvgVisitors"  
FROM NumVisitors; 
GO
--
--Create AvgSize View for ResortVisitors Subform
IF EXISTS (SELECT * FROM sys.views WHERE name=N'AvgSize') 
	DROP VIEW AvgSize
GO	
CREATE VIEW AvgSize
AS SELECT AVG(ResortSize) AS IndustryAvgSize
FROM Resort; 
GO 
--
--Create AvgSnowfall view for ResortVisitors Subform
IF EXISTS (SELECT * FROM sys.views WHERE name=N'AvgSnowFall') 
	DROP VIEW AvgSnowFall
GO
CREATE VIEW AvgSnowFall	
AS SELECT AVG(ResortAvgAnnualSnowfall) AS IndustryAvgSnow
FROM Resort;
GO
--
--Create CustomerNames view efor Customers form
IF EXISTS (SELECT * FROM sys.views WHERE name=N'CustomerNames') 
	DROP VIEW CustomerNames
GO
CREATE VIEW CustomerNames	
AS SELECT CustomerID, CustomerFirstName, CustomerLastName, CustomerLastName + ', ' + CustomerFirstName AS CustomerFullName
FROM Customer;
GO

