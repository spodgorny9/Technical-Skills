Slater Podgorny
6/6/2021
INFO 3240 Project Phase 3 
Peer Reviewed by: Sasha Shadrina
-----
-----
This database was built to assist Ski Corporation in creating and pricing a new season pass for skiing. The database and the forms associated provide useful information regarding Resorts, Regions, and Customers.
--
You should not need to rerun the build script and view, but if necessary follow this step:
1-Using SSMS run the BuildSkiCorporation.sql and SkiCorpView.sql files. 
-- 
Open the SkiCorporation.sln file to explore the forms
2- Click Start and the startup form will appear giving you the option to navigate through the available forms. 
3-Click the 'Customers' button to run the Customer Form
4-While in the Customer Form upload a picture for the customer to use on his season pass. This can be done by clicking the browse button, navigating to the IDPhoto included in the BuildSkiCorp file and then clicking upload.
5-Click through a few records to check which pass Customers qualify for. The pass eligibility should update automatically but if it does not, simply click the check eligibility button to override the process. 
6-You can search for a customer by typing his or her last name into the search box (if you would like to use this process, 'Toy' and 'Sumption' are lastnames contained in the database. 
--
Close the Customer form and click the Region button on the start up form. 
6-Scroll through the grid then type 'Aspen' into the search box and click the search button to filter the results.
7- Leave the % in the search box and type 'Rockies' to view all the Rocky Mountain Regions
--
Close the Region form and click Resort Visitors button on the start up form.
8-The form displays some key characteristics of each resort as well as who skied at the resort and when.
9-If you would like to compare the resort's characteristics to the industry averages, click the 'Compare Resort' button.  
--
Close the Resort Visitors form and click the Search Resorts Button on the start up form. 
10-The default parameters will return just about all the resorts so let's change them.
11-Set the following Parameters: Min Size = 500, Max Size = 2500, Min Lifts = 5, Max Lifts = 27, Region = I-70 Corridor(you will need to uncheck the check box), Snowfall = >200. The results above the grid provide some useful summary statistics. 
12- If your search returns only one resort(Subsitute Southern Rockies for I-70 Corridor and keep the rest of the parameters the same as above), the summary statistics that are displayed will differ. 
13- Close this form and the start up form. 
--
--REPORTS 
--
14- Navigate to the SkiCorporationReports Project and in the reports folder select the Region Report. Once the report opens click preview.
15- This report provides some basic information about regions and the resorts within them. To explore different regions, use the drop down menu at the top of the page and select your desired region then click 'view report.' 
16- Click the '+' icon near the region name to view the resorts within that region. 
--
Close the Region Report and open the Pass Report. This report allows you to search pass providers and types and displays details about the customers who have the defined pass. The report includes four parameters that allow the user to focus the results. 
17-The default parameter values will give the user a general view of the data but let's find some more specific information such as which customers with an IKON Season Plus pass skied during the Holiday Season(December 24-January 3). Input the following parameters: Pass Name = IKON, Type Category = Season Plus, Start Date = 12-24-2020, and End Date = 01-03-2021.
--
Thank you! 

--UDF: CustEmail - Takes in a string email address and determines whether the last 4 characters of the string are '.edu' allowing the company to determine whether the customer is eligible for a college pass.
--Procedures:
----btnPassElig: Evaluates customer email and age in order to determine which pass the customer is eligible for.
----btnResAnalysis: Uses the calculates summary statistics of a resort's key characteristics to compare it to the industry average. 
--View: SearchResorts - Gathers useful information about resorts that is displayed on the search form. 
