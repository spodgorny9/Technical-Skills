﻿Public Class SearchResorts
    Private Sub SearchResorts_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'SkiCorporationDataSet.SearchResorts' table. You can move, or remove it, as needed.
        'Me.SearchResortsTableAdapter.Fill(Me.SkiCorporationDataSet.SearchResorts)
        'TODO: This line of code loads data into the 'SkiCorporationDataSet.DistinctRegions' table. You can move, or remove it, as needed.
        Me.DistinctRegions.Fill(Me.SkiCorporationDataSet.DistinctRegions)

    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Try
            If cbxRegion.Checked = True Then
                Me.SearchResortsTableAdapter.FillBy1(Me.SkiCorporationDataSet.SearchResorts, Me.EvaluateRadioGroup(Me.grpSnow), CType(Me.txtMinSize.Text, Integer), CType(Me.txtMaxSize.Text, Integer), CType(Me.txtMinLifts.Text, Integer), CType(Me.txtMaxLifts.Text, Integer))
                cboRegion.Text = "All Regions"
            Else
                Me.SearchResortsTableAdapter.FillBy(Me.SkiCorporationDataSet.SearchResorts, Me.cboRegion.SelectedValue, Me.EvaluateRadioGroup(Me.grpSnow), CType(Me.txtMinSize.Text, Integer), CType(Me.txtMaxSize.Text, Integer), CType(Me.txtMinLifts.Text, Integer), CType(Me.txtMaxLifts.Text, Integer))

            End If
            CalcTotals()
        Catch ex As Exception
            MsgBox(ex.Message,, "Error in the Query")
        End Try
        Dim n As Integer
        n = Me.SearchResortsDataGridView.Rows.Count - 1
        If n = 0 Then
            MsgBox("No Resorts found!")
        End If


    End Sub

    Private Function EvaluateRadioGroup(ByVal grp As GroupBox) As Integer
        Dim rad As RadioButton
        For Each rad In grp.Controls
            If (rad.Checked) Then Return CType(rad.Tag, Integer)
        Next rad
        Return 0.0
    End Function

    Private Sub CalcTotals()
        Dim count As Integer
        count = Me.SearchResortsDataGridView.Rows.Count - 1
        lblCount.Text = count.ToString

        'check to see if multiple records returned and if there are calc summary stats
        If (count > 1) Then
            Dim AvgSnowSum As Decimal
            Dim SizeSum As Decimal
            Dim dgvr As System.Windows.Forms.DataGridViewRow
            For Each dgvr In Me.SearchResortsDataGridView.Rows
                SizeSum += dgvr.Cells("ResortSize").Value
                AvgSnowSum += dgvr.Cells("AvgSnowfall").Value
            Next dgvr
            'display avg snow 
            lblAvgSnowfall.Visible = True
            lblAvgSnowTitle.Visible = True
            Dim AvgSnow As Decimal
            AvgSnow = AvgSnowSum / count
            lblAvgSnowfall.Text = AvgSnow.ToString("#,###.#0 inches")
            'display total size sum
            lblSize.Visible = True
            lblSizeTitle.Visible = True
            lblSize.Text = SizeSum.ToString("#,### acres")
        Else
            lblAvgSnowfall.Visible = False
            lblAvgSnowTitle.Visible = False
            lblSize.Visible = False
            lblSizeTitle.Visible = False

        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub CustomersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CustomersToolStripMenuItem.Click
        Try
            Dim frmCustomers As New Customers
            frmCustomers.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub RegionToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegionToolStripMenuItem.Click
        Try
            Dim frmRegion As New Region
            frmRegion.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ResortVisitorsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResortVisitorsToolStripMenuItem.Click
        Try
            Dim frmResortVisitors As New ResortVisitors
            frmResortVisitors.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub SearchResortsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchResortsToolStripMenuItem.Click
        Try
            Dim frmSearch As New SearchResorts
            frmSearch.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub ReadMeFileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ReadMeFileToolStripMenuItem.Click
        Try
            Dim frmReadMe As New ReadMe
            frmReadMe.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class