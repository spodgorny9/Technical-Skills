﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Customers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim CustomerIDLabel As System.Windows.Forms.Label
        Dim CustomerFirstNameLabel As System.Windows.Forms.Label
        Dim CustomerLastNameLabel As System.Windows.Forms.Label
        Dim CustomerEmailLabel As System.Windows.Forms.Label
        Dim CustomerDOBLabel As System.Windows.Forms.Label
        Dim CustomerAddressLabel As System.Windows.Forms.Label
        Dim CustomerCityLabel As System.Windows.Forms.Label
        Dim CustomerZipCodeLabel As System.Windows.Forms.Label
        Dim CustomerCountryLabel As System.Windows.Forms.Label
        Dim CustomerStateLabel As System.Windows.Forms.Label
        Dim CustomerPhoto1Label As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Customers))
        Me.SkiCorporationDataSet = New SkiCorporationForms.SkiCorporationDataSet()
        Me.CustomerBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CustomerTableAdapter = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.CustomerTableAdapter()
        Me.TableAdapterManager = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.TableAdapterManager()
        Me.StatesTableAdapter = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.StatesTableAdapter()
        Me.CustomerBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.CustomerBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.CustomerIDTextBox = New System.Windows.Forms.TextBox()
        Me.CustomerFirstNameTextBox = New System.Windows.Forms.TextBox()
        Me.CustomerLastNameTextBox = New System.Windows.Forms.TextBox()
        Me.txtCustomerEmail = New System.Windows.Forms.TextBox()
        Me.CustomerDOBDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.CustomerAddressTextBox = New System.Windows.Forms.TextBox()
        Me.CustomerCityTextBox = New System.Windows.Forms.TextBox()
        Me.StatesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CustomerCountryTextBox = New System.Windows.Forms.TextBox()
        Me.ResortTableAdapter1 = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.ResortTableAdapter()
        Me.ResortTableAdapter2 = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.ResortTableAdapter()
        Me.CustomerBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblCustTitle = New System.Windows.Forms.Label()
        Me.FillByToolStrip = New System.Windows.Forms.ToolStrip()
        Me.LastNameToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.LastNameToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.FillByToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.StatesBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.CustomerStateComboBox = New System.Windows.Forms.ComboBox()
        Me.StatesBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.CustomerBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.StatesBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblCustElig = New System.Windows.Forms.Label()
        Me.btnPassElig = New System.Windows.Forms.Button()
        Me.CustomerPhoto1PictureBox = New System.Windows.Forms.PictureBox()
        Me.txtFileName = New System.Windows.Forms.TextBox()
        Me.btnUpload = New System.Windows.Forms.Button()
        Me.btnBrowse = New System.Windows.Forms.Button()
        Me.btnRemovePhoto = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.CustomerBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CustomerZipMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.btnExit = New System.Windows.Forms.Button()
        CustomerIDLabel = New System.Windows.Forms.Label()
        CustomerFirstNameLabel = New System.Windows.Forms.Label()
        CustomerLastNameLabel = New System.Windows.Forms.Label()
        CustomerEmailLabel = New System.Windows.Forms.Label()
        CustomerDOBLabel = New System.Windows.Forms.Label()
        CustomerAddressLabel = New System.Windows.Forms.Label()
        CustomerCityLabel = New System.Windows.Forms.Label()
        CustomerZipCodeLabel = New System.Windows.Forms.Label()
        CustomerCountryLabel = New System.Windows.Forms.Label()
        CustomerStateLabel = New System.Windows.Forms.Label()
        CustomerPhoto1Label = New System.Windows.Forms.Label()
        CType(Me.SkiCorporationDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.CustomerBindingNavigator.SuspendLayout()
        CType(Me.StatesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FillByToolStrip.SuspendLayout()
        CType(Me.StatesBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StatesBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StatesBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerPhoto1PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CustomerIDLabel
        '
        CustomerIDLabel.AutoSize = True
        CustomerIDLabel.Location = New System.Drawing.Point(73, 157)
        CustomerIDLabel.Name = "CustomerIDLabel"
        CustomerIDLabel.Size = New System.Drawing.Size(89, 17)
        CustomerIDLabel.TabIndex = 1
        CustomerIDLabel.Text = "Customer ID:"
        '
        'CustomerFirstNameLabel
        '
        CustomerFirstNameLabel.AutoSize = True
        CustomerFirstNameLabel.Location = New System.Drawing.Point(73, 185)
        CustomerFirstNameLabel.Name = "CustomerFirstNameLabel"
        CustomerFirstNameLabel.Size = New System.Drawing.Size(144, 17)
        CustomerFirstNameLabel.TabIndex = 3
        CustomerFirstNameLabel.Text = "Customer First Name:"
        '
        'CustomerLastNameLabel
        '
        CustomerLastNameLabel.AutoSize = True
        CustomerLastNameLabel.Location = New System.Drawing.Point(73, 213)
        CustomerLastNameLabel.Name = "CustomerLastNameLabel"
        CustomerLastNameLabel.Size = New System.Drawing.Size(144, 17)
        CustomerLastNameLabel.TabIndex = 5
        CustomerLastNameLabel.Text = "Customer Last Name:"
        '
        'CustomerEmailLabel
        '
        CustomerEmailLabel.AutoSize = True
        CustomerEmailLabel.Location = New System.Drawing.Point(73, 241)
        CustomerEmailLabel.Name = "CustomerEmailLabel"
        CustomerEmailLabel.Size = New System.Drawing.Size(110, 17)
        CustomerEmailLabel.TabIndex = 7
        CustomerEmailLabel.Text = "Customer Email:"
        '
        'CustomerDOBLabel
        '
        CustomerDOBLabel.AutoSize = True
        CustomerDOBLabel.Location = New System.Drawing.Point(73, 270)
        CustomerDOBLabel.Name = "CustomerDOBLabel"
        CustomerDOBLabel.Size = New System.Drawing.Size(106, 17)
        CustomerDOBLabel.TabIndex = 9
        CustomerDOBLabel.Text = "Customer DOB:"
        '
        'CustomerAddressLabel
        '
        CustomerAddressLabel.AutoSize = True
        CustomerAddressLabel.Location = New System.Drawing.Point(438, 157)
        CustomerAddressLabel.Name = "CustomerAddressLabel"
        CustomerAddressLabel.Size = New System.Drawing.Size(128, 17)
        CustomerAddressLabel.TabIndex = 11
        CustomerAddressLabel.Text = "Customer Address:"
        '
        'CustomerCityLabel
        '
        CustomerCityLabel.AutoSize = True
        CustomerCityLabel.Location = New System.Drawing.Point(438, 185)
        CustomerCityLabel.Name = "CustomerCityLabel"
        CustomerCityLabel.Size = New System.Drawing.Size(99, 17)
        CustomerCityLabel.TabIndex = 13
        CustomerCityLabel.Text = "Customer City:"
        '
        'CustomerZipCodeLabel
        '
        CustomerZipCodeLabel.AutoSize = True
        CustomerZipCodeLabel.Location = New System.Drawing.Point(438, 244)
        CustomerZipCodeLabel.Name = "CustomerZipCodeLabel"
        CustomerZipCodeLabel.Size = New System.Drawing.Size(133, 17)
        CustomerZipCodeLabel.TabIndex = 17
        CustomerZipCodeLabel.Text = "Customer Zip Code:"
        '
        'CustomerCountryLabel
        '
        CustomerCountryLabel.AutoSize = True
        CustomerCountryLabel.Location = New System.Drawing.Point(438, 272)
        CustomerCountryLabel.Name = "CustomerCountryLabel"
        CustomerCountryLabel.Size = New System.Drawing.Size(125, 17)
        CustomerCountryLabel.TabIndex = 19
        CustomerCountryLabel.Text = "Customer Country:"
        '
        'CustomerStateLabel
        '
        CustomerStateLabel.AutoSize = True
        CustomerStateLabel.Location = New System.Drawing.Point(438, 213)
        CustomerStateLabel.Name = "CustomerStateLabel"
        CustomerStateLabel.Size = New System.Drawing.Size(109, 17)
        CustomerStateLabel.TabIndex = 22
        CustomerStateLabel.Text = "Customer State:"
        '
        'CustomerPhoto1Label
        '
        CustomerPhoto1Label.AutoSize = True
        CustomerPhoto1Label.Location = New System.Drawing.Point(73, 328)
        CustomerPhoto1Label.Name = "CustomerPhoto1Label"
        CustomerPhoto1Label.Size = New System.Drawing.Size(113, 17)
        CustomerPhoto1Label.TabIndex = 25
        CustomerPhoto1Label.Text = "Customer Photo:"
        '
        'SkiCorporationDataSet
        '
        Me.SkiCorporationDataSet.DataSetName = "SkiCorporationDataSet"
        Me.SkiCorporationDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CustomerBindingSource
        '
        Me.CustomerBindingSource.DataMember = "Customer"
        Me.CustomerBindingSource.DataSource = Me.SkiCorporationDataSet
        '
        'CustomerTableAdapter
        '
        Me.CustomerTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AccommodationTableAdapter = Nothing
        Me.TableAdapterManager.AccommodationTypeTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CustomerHistoryTableAdapter = Nothing
        Me.TableAdapterManager.CustomerTableAdapter = Me.CustomerTableAdapter
        Me.TableAdapterManager.PassTableAdapter = Nothing
        Me.TableAdapterManager.PassTypeTableAdapter = Nothing
        Me.TableAdapterManager.RegionAccommodationTableAdapter = Nothing
        Me.TableAdapterManager.RegionTableAdapter = Nothing
        Me.TableAdapterManager.ResortPassTableAdapter = Nothing
        Me.TableAdapterManager.ResortTableAdapter = Nothing
        Me.TableAdapterManager.StatesTableAdapter = Me.StatesTableAdapter
        Me.TableAdapterManager.UpdateOrder = SkiCorporationForms.SkiCorporationDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'StatesTableAdapter
        '
        Me.StatesTableAdapter.ClearBeforeFill = True
        '
        'CustomerBindingNavigator
        '
        Me.CustomerBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.CustomerBindingNavigator.BindingSource = Me.CustomerBindingSource
        Me.CustomerBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.CustomerBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.CustomerBindingNavigator.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.CustomerBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.CustomerBindingNavigatorSaveItem})
        Me.CustomerBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.CustomerBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.CustomerBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.CustomerBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.CustomerBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.CustomerBindingNavigator.Name = "CustomerBindingNavigator"
        Me.CustomerBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.CustomerBindingNavigator.Size = New System.Drawing.Size(884, 27)
        Me.CustomerBindingNavigator.TabIndex = 0
        Me.CustomerBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(45, 24)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Enabled = False
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        Me.BindingNavigatorDeleteItem.Visible = False
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 27)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 27)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 27)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 27)
        '
        'CustomerBindingNavigatorSaveItem
        '
        Me.CustomerBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CustomerBindingNavigatorSaveItem.Image = CType(resources.GetObject("CustomerBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.CustomerBindingNavigatorSaveItem.Name = "CustomerBindingNavigatorSaveItem"
        Me.CustomerBindingNavigatorSaveItem.Size = New System.Drawing.Size(29, 24)
        Me.CustomerBindingNavigatorSaveItem.Text = "Save Data"
        '
        'CustomerIDTextBox
        '
        Me.CustomerIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerID", True))
        Me.CustomerIDTextBox.Location = New System.Drawing.Point(223, 154)
        Me.CustomerIDTextBox.Name = "CustomerIDTextBox"
        Me.CustomerIDTextBox.ReadOnly = True
        Me.CustomerIDTextBox.Size = New System.Drawing.Size(200, 22)
        Me.CustomerIDTextBox.TabIndex = 2
        '
        'CustomerFirstNameTextBox
        '
        Me.CustomerFirstNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerFirstName", True))
        Me.CustomerFirstNameTextBox.Location = New System.Drawing.Point(223, 182)
        Me.CustomerFirstNameTextBox.Name = "CustomerFirstNameTextBox"
        Me.CustomerFirstNameTextBox.Size = New System.Drawing.Size(200, 22)
        Me.CustomerFirstNameTextBox.TabIndex = 4
        '
        'CustomerLastNameTextBox
        '
        Me.CustomerLastNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerLastName", True))
        Me.CustomerLastNameTextBox.Location = New System.Drawing.Point(223, 210)
        Me.CustomerLastNameTextBox.Name = "CustomerLastNameTextBox"
        Me.CustomerLastNameTextBox.Size = New System.Drawing.Size(200, 22)
        Me.CustomerLastNameTextBox.TabIndex = 6
        '
        'txtCustomerEmail
        '
        Me.txtCustomerEmail.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerEmail", True))
        Me.txtCustomerEmail.Location = New System.Drawing.Point(223, 238)
        Me.txtCustomerEmail.Name = "txtCustomerEmail"
        Me.txtCustomerEmail.Size = New System.Drawing.Size(200, 22)
        Me.txtCustomerEmail.TabIndex = 8
        '
        'CustomerDOBDateTimePicker
        '
        Me.CustomerDOBDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.CustomerBindingSource, "CustomerDOB", True))
        Me.CustomerDOBDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.CustomerDOBDateTimePicker.Location = New System.Drawing.Point(223, 266)
        Me.CustomerDOBDateTimePicker.Name = "CustomerDOBDateTimePicker"
        Me.CustomerDOBDateTimePicker.Size = New System.Drawing.Size(200, 22)
        Me.CustomerDOBDateTimePicker.TabIndex = 10
        '
        'CustomerAddressTextBox
        '
        Me.CustomerAddressTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerAddress", True))
        Me.CustomerAddressTextBox.Location = New System.Drawing.Point(588, 154)
        Me.CustomerAddressTextBox.Name = "CustomerAddressTextBox"
        Me.CustomerAddressTextBox.Size = New System.Drawing.Size(213, 22)
        Me.CustomerAddressTextBox.TabIndex = 12
        '
        'CustomerCityTextBox
        '
        Me.CustomerCityTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerCity", True))
        Me.CustomerCityTextBox.Location = New System.Drawing.Point(588, 182)
        Me.CustomerCityTextBox.Name = "CustomerCityTextBox"
        Me.CustomerCityTextBox.Size = New System.Drawing.Size(213, 22)
        Me.CustomerCityTextBox.TabIndex = 14
        '
        'StatesBindingSource
        '
        Me.StatesBindingSource.DataMember = "States"
        Me.StatesBindingSource.DataSource = Me.SkiCorporationDataSet
        '
        'CustomerCountryTextBox
        '
        Me.CustomerCountryTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerCountry", True))
        Me.CustomerCountryTextBox.Location = New System.Drawing.Point(588, 269)
        Me.CustomerCountryTextBox.Name = "CustomerCountryTextBox"
        Me.CustomerCountryTextBox.Size = New System.Drawing.Size(213, 22)
        Me.CustomerCountryTextBox.TabIndex = 20
        '
        'ResortTableAdapter1
        '
        Me.ResortTableAdapter1.ClearBeforeFill = True
        '
        'ResortTableAdapter2
        '
        Me.ResortTableAdapter2.ClearBeforeFill = True
        '
        'CustomerBindingSource1
        '
        Me.CustomerBindingSource1.DataMember = "Customer"
        Me.CustomerBindingSource1.DataSource = Me.SkiCorporationDataSet
        '
        'lblCustTitle
        '
        Me.lblCustTitle.AutoSize = True
        Me.lblCustTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustTitle.Location = New System.Drawing.Point(367, 110)
        Me.lblCustTitle.Name = "lblCustTitle"
        Me.lblCustTitle.Size = New System.Drawing.Size(138, 29)
        Me.lblCustTitle.TabIndex = 21
        Me.lblCustTitle.Text = "Customers"
        '
        'FillByToolStrip
        '
        Me.FillByToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.FillByToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LastNameToolStripLabel, Me.LastNameToolStripTextBox, Me.FillByToolStripButton, Me.ToolStripButton1})
        Me.FillByToolStrip.Location = New System.Drawing.Point(0, 27)
        Me.FillByToolStrip.Name = "FillByToolStrip"
        Me.FillByToolStrip.Size = New System.Drawing.Size(884, 27)
        Me.FillByToolStrip.TabIndex = 22
        Me.FillByToolStrip.Text = "FillByToolStrip"
        '
        'LastNameToolStripLabel
        '
        Me.LastNameToolStripLabel.Name = "LastNameToolStripLabel"
        Me.LastNameToolStripLabel.Size = New System.Drawing.Size(82, 24)
        Me.LastNameToolStripLabel.Text = "Last Name:"
        '
        'LastNameToolStripTextBox
        '
        Me.LastNameToolStripTextBox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.LastNameToolStripTextBox.Name = "LastNameToolStripTextBox"
        Me.LastNameToolStripTextBox.Size = New System.Drawing.Size(100, 27)
        '
        'FillByToolStripButton
        '
        Me.FillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillByToolStripButton.Name = "FillByToolStripButton"
        Me.FillByToolStripButton.Size = New System.Drawing.Size(57, 24)
        Me.FillByToolStripButton.Text = "Search"
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(49, 24)
        Me.ToolStripButton1.Text = "Reset"
        '
        'StatesBindingSource1
        '
        Me.StatesBindingSource1.DataMember = "States"
        Me.StatesBindingSource1.DataSource = Me.SkiCorporationDataSet
        '
        'CustomerStateComboBox
        '
        Me.CustomerStateComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.CustomerBindingSource, "StateName", True))
        Me.CustomerStateComboBox.DataSource = Me.StatesBindingSource3
        Me.CustomerStateComboBox.DisplayMember = "StateName"
        Me.CustomerStateComboBox.FormattingEnabled = True
        Me.CustomerStateComboBox.Location = New System.Drawing.Point(588, 213)
        Me.CustomerStateComboBox.Name = "CustomerStateComboBox"
        Me.CustomerStateComboBox.Size = New System.Drawing.Size(121, 24)
        Me.CustomerStateComboBox.TabIndex = 16
        Me.CustomerStateComboBox.ValueMember = "StateName"
        '
        'StatesBindingSource3
        '
        Me.StatesBindingSource3.DataMember = "States"
        Me.StatesBindingSource3.DataSource = Me.SkiCorporationDataSet
        '
        'CustomerBindingSource2
        '
        Me.CustomerBindingSource2.DataMember = "Customer"
        Me.CustomerBindingSource2.DataSource = Me.SkiCorporationDataSet
        '
        'StatesBindingSource2
        '
        Me.StatesBindingSource2.DataMember = "States"
        Me.StatesBindingSource2.DataSource = Me.SkiCorporationDataSet
        '
        'lblCustElig
        '
        Me.lblCustElig.AutoSize = True
        Me.lblCustElig.Location = New System.Drawing.Point(318, 328)
        Me.lblCustElig.Name = "lblCustElig"
        Me.lblCustElig.Size = New System.Drawing.Size(105, 17)
        Me.lblCustElig.TabIndex = 24
        Me.lblCustElig.Text = "Pass Eligibility: "
        '
        'btnPassElig
        '
        Me.btnPassElig.Location = New System.Drawing.Point(654, 311)
        Me.btnPassElig.Name = "btnPassElig"
        Me.btnPassElig.Size = New System.Drawing.Size(147, 34)
        Me.btnPassElig.TabIndex = 25
        Me.btnPassElig.Text = "Check Eligibility"
        Me.btnPassElig.UseVisualStyleBackColor = True
        '
        'CustomerPhoto1PictureBox
        '
        Me.CustomerPhoto1PictureBox.DataBindings.Add(New System.Windows.Forms.Binding("Image", Me.CustomerBindingSource, "CustomerPhoto1", True))
        Me.CustomerPhoto1PictureBox.Location = New System.Drawing.Point(76, 348)
        Me.CustomerPhoto1PictureBox.Name = "CustomerPhoto1PictureBox"
        Me.CustomerPhoto1PictureBox.Size = New System.Drawing.Size(181, 161)
        Me.CustomerPhoto1PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CustomerPhoto1PictureBox.TabIndex = 26
        Me.CustomerPhoto1PictureBox.TabStop = False
        '
        'txtFileName
        '
        Me.txtFileName.Location = New System.Drawing.Point(76, 514)
        Me.txtFileName.Name = "txtFileName"
        Me.txtFileName.Size = New System.Drawing.Size(181, 22)
        Me.txtFileName.TabIndex = 27
        '
        'btnUpload
        '
        Me.btnUpload.Location = New System.Drawing.Point(168, 543)
        Me.btnUpload.Name = "btnUpload"
        Me.btnUpload.Size = New System.Drawing.Size(89, 33)
        Me.btnUpload.TabIndex = 28
        Me.btnUpload.Text = "Upload"
        Me.btnUpload.UseVisualStyleBackColor = True
        '
        'btnBrowse
        '
        Me.btnBrowse.Location = New System.Drawing.Point(76, 543)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(86, 33)
        Me.btnBrowse.TabIndex = 29
        Me.btnBrowse.Text = "Browse"
        Me.btnBrowse.UseVisualStyleBackColor = True
        '
        'btnRemovePhoto
        '
        Me.btnRemovePhoto.Location = New System.Drawing.Point(76, 582)
        Me.btnRemovePhoto.Name = "btnRemovePhoto"
        Me.btnRemovePhoto.Size = New System.Drawing.Size(181, 23)
        Me.btnRemovePhoto.TabIndex = 30
        Me.btnRemovePhoto.Text = "Remove Photo"
        Me.btnRemovePhoto.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'CustomerBindingSource3
        '
        Me.CustomerBindingSource3.DataMember = "Customer"
        Me.CustomerBindingSource3.DataSource = Me.SkiCorporationDataSet
        '
        'PictureBox1
        '
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(76, 66)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(152, 82)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 31
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(73, 66)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(105, 17)
        Me.Label1.TabIndex = 32
        Me.Label1.Text = "Ski Corporation"
        '
        'CustomerZipMaskedTextBox
        '
        Me.CustomerZipMaskedTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerZipCode", True))
        Me.CustomerZipMaskedTextBox.Location = New System.Drawing.Point(588, 244)
        Me.CustomerZipMaskedTextBox.Mask = "00000-9999"
        Me.CustomerZipMaskedTextBox.Name = "CustomerZipMaskedTextBox"
        Me.CustomerZipMaskedTextBox.Size = New System.Drawing.Size(121, 22)
        Me.CustomerZipMaskedTextBox.TabIndex = 18
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(725, 115)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 33
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Customers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(884, 634)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.CustomerZipMaskedTextBox)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnRemovePhoto)
        Me.Controls.Add(Me.btnBrowse)
        Me.Controls.Add(Me.btnUpload)
        Me.Controls.Add(Me.txtFileName)
        Me.Controls.Add(CustomerPhoto1Label)
        Me.Controls.Add(Me.CustomerPhoto1PictureBox)
        Me.Controls.Add(Me.btnPassElig)
        Me.Controls.Add(Me.lblCustElig)
        Me.Controls.Add(CustomerStateLabel)
        Me.Controls.Add(Me.CustomerStateComboBox)
        Me.Controls.Add(Me.FillByToolStrip)
        Me.Controls.Add(Me.lblCustTitle)
        Me.Controls.Add(CustomerIDLabel)
        Me.Controls.Add(Me.CustomerIDTextBox)
        Me.Controls.Add(CustomerFirstNameLabel)
        Me.Controls.Add(Me.CustomerFirstNameTextBox)
        Me.Controls.Add(CustomerLastNameLabel)
        Me.Controls.Add(Me.CustomerLastNameTextBox)
        Me.Controls.Add(CustomerEmailLabel)
        Me.Controls.Add(Me.txtCustomerEmail)
        Me.Controls.Add(CustomerDOBLabel)
        Me.Controls.Add(Me.CustomerDOBDateTimePicker)
        Me.Controls.Add(CustomerAddressLabel)
        Me.Controls.Add(Me.CustomerAddressTextBox)
        Me.Controls.Add(CustomerCityLabel)
        Me.Controls.Add(Me.CustomerCityTextBox)
        Me.Controls.Add(CustomerZipCodeLabel)
        Me.Controls.Add(CustomerCountryLabel)
        Me.Controls.Add(Me.CustomerCountryTextBox)
        Me.Controls.Add(Me.CustomerBindingNavigator)
        Me.Name = "Customers"
        Me.Text = "Customers"
        CType(Me.SkiCorporationDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.CustomerBindingNavigator.ResumeLayout(False)
        Me.CustomerBindingNavigator.PerformLayout()
        CType(Me.StatesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FillByToolStrip.ResumeLayout(False)
        Me.FillByToolStrip.PerformLayout()
        CType(Me.StatesBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StatesBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StatesBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerPhoto1PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents SkiCorporationDataSet As SkiCorporationDataSet
    Friend WithEvents CustomerBindingSource As BindingSource
    Friend WithEvents CustomerTableAdapter As SkiCorporationDataSetTableAdapters.CustomerTableAdapter
    Friend WithEvents TableAdapterManager As SkiCorporationDataSetTableAdapters.TableAdapterManager
    Friend WithEvents CustomerBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents CustomerBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents CustomerIDTextBox As TextBox
    Friend WithEvents CustomerFirstNameTextBox As TextBox
    Friend WithEvents CustomerLastNameTextBox As TextBox
    Friend WithEvents txtCustomerEmail As TextBox
    Friend WithEvents CustomerDOBDateTimePicker As DateTimePicker
    Friend WithEvents CustomerAddressTextBox As TextBox
    Friend WithEvents CustomerCityTextBox As TextBox
    Friend WithEvents CustomerCountryTextBox As TextBox
    Friend WithEvents StatesTableAdapter As SkiCorporationDataSetTableAdapters.StatesTableAdapter
    Friend WithEvents StatesBindingSource As BindingSource
    Friend WithEvents ResortTableAdapter1 As SkiCorporationDataSetTableAdapters.ResortTableAdapter
    Friend WithEvents ResortTableAdapter2 As SkiCorporationDataSetTableAdapters.ResortTableAdapter
    Friend WithEvents CustomerBindingSource1 As BindingSource
    Friend WithEvents lblCustTitle As Label
    Friend WithEvents FillByToolStrip As ToolStrip
    Friend WithEvents LastNameToolStripLabel As ToolStripLabel
    Friend WithEvents LastNameToolStripTextBox As ToolStripTextBox
    Friend WithEvents FillByToolStripButton As ToolStripButton
    Friend WithEvents ToolStripButton1 As ToolStripButton
    Friend WithEvents StatesBindingSource1 As BindingSource
    Friend WithEvents CustomerStateComboBox As ComboBox
    Friend WithEvents StatesBindingSource2 As BindingSource
    Friend WithEvents lblCustElig As Label
    Friend WithEvents btnPassElig As Button
    Friend WithEvents CustomerPhoto1PictureBox As PictureBox
    Friend WithEvents txtFileName As TextBox
    Friend WithEvents btnUpload As Button
    Friend WithEvents btnBrowse As Button
    Friend WithEvents btnRemovePhoto As Button
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents CustomerBindingSource2 As BindingSource
    Friend WithEvents CustomerBindingSource3 As BindingSource
    Friend WithEvents StatesBindingSource3 As BindingSource
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents CustomerZipMaskedTextBox As MaskedTextBox
    Friend WithEvents btnExit As Button
End Class
