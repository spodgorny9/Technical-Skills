﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Resort
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Resort))
        Me.SkiCorporationDataSet = New SkiCorporationForms.SkiCorporationDataSet()
        Me.ResortBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ResortTableAdapter = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.ResortTableAdapter()
        Me.TableAdapterManager = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.TableAdapterManager()
        Me.RegionTableAdapter = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.RegionTableAdapter()
        Me.ResortBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ResortBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.RegionBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ResortDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.RegionBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.SkiCorporationDataSet1 = New SkiCorporationForms.SkiCorporationDataSet()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FillBy1ToolStrip = New System.Windows.Forms.ToolStrip()
        Me.ResortNameToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.ResortNameToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.FillBy1ToolStripButton = New System.Windows.Forms.ToolStripButton()
        CType(Me.SkiCorporationDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResortBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResortBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ResortBindingNavigator.SuspendLayout()
        CType(Me.RegionBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResortDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RegionBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SkiCorporationDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FillBy1ToolStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'SkiCorporationDataSet
        '
        Me.SkiCorporationDataSet.DataSetName = "SkiCorporationDataSet"
        Me.SkiCorporationDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ResortBindingSource
        '
        Me.ResortBindingSource.DataMember = "Resort"
        Me.ResortBindingSource.DataSource = Me.SkiCorporationDataSet
        '
        'ResortTableAdapter
        '
        Me.ResortTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AccommodationTableAdapter = Nothing
        Me.TableAdapterManager.AccommodationTypeTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CustomerHistoryTableAdapter = Nothing
        Me.TableAdapterManager.CustomerTableAdapter = Nothing
        Me.TableAdapterManager.PassTableAdapter = Nothing
        Me.TableAdapterManager.PassTypeTableAdapter = Nothing
        Me.TableAdapterManager.RegionAccommodationTableAdapter = Nothing
        Me.TableAdapterManager.RegionTableAdapter = Me.RegionTableAdapter
        Me.TableAdapterManager.ResortPassTableAdapter = Nothing
        Me.TableAdapterManager.ResortTableAdapter = Me.ResortTableAdapter
        Me.TableAdapterManager.UpdateOrder = SkiCorporationForms.SkiCorporationDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'RegionTableAdapter
        '
        Me.RegionTableAdapter.ClearBeforeFill = True
        '
        'ResortBindingNavigator
        '
        Me.ResortBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.ResortBindingNavigator.BindingSource = Me.ResortBindingSource
        Me.ResortBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.ResortBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.ResortBindingNavigator.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ResortBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.ResortBindingNavigatorSaveItem})
        Me.ResortBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.ResortBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.ResortBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.ResortBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.ResortBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.ResortBindingNavigator.Name = "ResortBindingNavigator"
        Me.ResortBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.ResortBindingNavigator.Size = New System.Drawing.Size(1292, 31)
        Me.ResortBindingNavigator.TabIndex = 0
        Me.ResortBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(29, 28)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(45, 28)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(29, 28)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(29, 28)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(29, 28)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 31)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 27)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 31)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(29, 28)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(29, 28)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 31)
        '
        'ResortBindingNavigatorSaveItem
        '
        Me.ResortBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ResortBindingNavigatorSaveItem.Image = CType(resources.GetObject("ResortBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.ResortBindingNavigatorSaveItem.Name = "ResortBindingNavigatorSaveItem"
        Me.ResortBindingNavigatorSaveItem.Size = New System.Drawing.Size(29, 28)
        Me.ResortBindingNavigatorSaveItem.Text = "Save Data"
        '
        'RegionBindingSource
        '
        Me.RegionBindingSource.DataMember = "Region"
        Me.RegionBindingSource.DataSource = Me.SkiCorporationDataSet
        '
        'ResortDataGridView
        '
        Me.ResortDataGridView.AutoGenerateColumns = False
        Me.ResortDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ResortDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7})
        Me.ResortDataGridView.DataSource = Me.ResortBindingSource
        Me.ResortDataGridView.Location = New System.Drawing.Point(79, 105)
        Me.ResortDataGridView.Name = "ResortDataGridView"
        Me.ResortDataGridView.RowHeadersWidth = 51
        Me.ResortDataGridView.RowTemplate.Height = 24
        Me.ResortDataGridView.Size = New System.Drawing.Size(1135, 220)
        Me.ResortDataGridView.TabIndex = 1
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "ResortID"
        Me.DataGridViewTextBoxColumn1.HeaderText = "ResortID"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 125
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "RegionID"
        Me.DataGridViewTextBoxColumn2.DataSource = Me.RegionBindingSource1
        Me.DataGridViewTextBoxColumn2.DisplayMember = "RegionName"
        Me.DataGridViewTextBoxColumn2.HeaderText = "RegionID"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn2.ValueMember = "RegionID"
        Me.DataGridViewTextBoxColumn2.Width = 125
        '
        'RegionBindingSource1
        '
        Me.RegionBindingSource1.DataMember = "Region"
        Me.RegionBindingSource1.DataSource = Me.SkiCorporationDataSet1
        '
        'SkiCorporationDataSet1
        '
        Me.SkiCorporationDataSet1.DataSetName = "SkiCorporationDataSet"
        Me.SkiCorporationDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "ResortName"
        Me.DataGridViewTextBoxColumn3.HeaderText = "ResortName"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 125
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "ResortAvgAnnualSnowfall"
        Me.DataGridViewTextBoxColumn4.HeaderText = "ResortAvgAnnualSnowfall"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 125
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "ResortSize"
        Me.DataGridViewTextBoxColumn5.HeaderText = "ResortSize"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 125
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "NumberOfLifts"
        Me.DataGridViewTextBoxColumn6.HeaderText = "NumberOfLifts"
        Me.DataGridViewTextBoxColumn6.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 125
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "ResortWebsite"
        Me.DataGridViewTextBoxColumn7.HeaderText = "ResortWebsite"
        Me.DataGridViewTextBoxColumn7.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.Width = 125
        '
        'FillBy1ToolStrip
        '
        Me.FillBy1ToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.FillBy1ToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ResortNameToolStripLabel, Me.ResortNameToolStripTextBox, Me.FillBy1ToolStripButton})
        Me.FillBy1ToolStrip.Location = New System.Drawing.Point(0, 31)
        Me.FillBy1ToolStrip.Name = "FillBy1ToolStrip"
        Me.FillBy1ToolStrip.Size = New System.Drawing.Size(1292, 31)
        Me.FillBy1ToolStrip.TabIndex = 2
        Me.FillBy1ToolStrip.Text = "FillBy1ToolStrip"
        '
        'ResortNameToolStripLabel
        '
        Me.ResortNameToolStripLabel.Name = "ResortNameToolStripLabel"
        Me.ResortNameToolStripLabel.Size = New System.Drawing.Size(94, 28)
        Me.ResortNameToolStripLabel.Text = "ResortName:"
        '
        'ResortNameToolStripTextBox
        '
        Me.ResortNameToolStripTextBox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ResortNameToolStripTextBox.Name = "ResortNameToolStripTextBox"
        Me.ResortNameToolStripTextBox.Size = New System.Drawing.Size(100, 31)
        '
        'FillBy1ToolStripButton
        '
        Me.FillBy1ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillBy1ToolStripButton.Name = "FillBy1ToolStripButton"
        Me.FillBy1ToolStripButton.Size = New System.Drawing.Size(57, 28)
        Me.FillBy1ToolStripButton.Text = "Search"
        '
        'Resort
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1292, 450)
        Me.Controls.Add(Me.FillBy1ToolStrip)
        Me.Controls.Add(Me.ResortDataGridView)
        Me.Controls.Add(Me.ResortBindingNavigator)
        Me.Name = "Resort"
        Me.Text = "Resort"
        CType(Me.SkiCorporationDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResortBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResortBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResortBindingNavigator.ResumeLayout(False)
        Me.ResortBindingNavigator.PerformLayout()
        CType(Me.RegionBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResortDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RegionBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SkiCorporationDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FillBy1ToolStrip.ResumeLayout(False)
        Me.FillBy1ToolStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents SkiCorporationDataSet As SkiCorporationDataSet
    Friend WithEvents ResortBindingSource As BindingSource
    Friend WithEvents ResortTableAdapter As SkiCorporationDataSetTableAdapters.ResortTableAdapter
    Friend WithEvents TableAdapterManager As SkiCorporationDataSetTableAdapters.TableAdapterManager
    Friend WithEvents ResortBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents ResortBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents RegionTableAdapter As SkiCorporationDataSetTableAdapters.RegionTableAdapter
    Friend WithEvents RegionBindingSource As BindingSource
    Friend WithEvents ResortDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewImageColumn1 As DataGridViewImageColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents SkiCorporationDataSet1 As SkiCorporationDataSet
    Friend WithEvents RegionBindingSource1 As BindingSource
    Friend WithEvents FillBy1ToolStrip As ToolStrip
    Friend WithEvents ResortNameToolStripLabel As ToolStripLabel
    Friend WithEvents ResortNameToolStripTextBox As ToolStripTextBox
    Friend WithEvents FillBy1ToolStripButton As ToolStripButton
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewComboBoxColumn
End Class
