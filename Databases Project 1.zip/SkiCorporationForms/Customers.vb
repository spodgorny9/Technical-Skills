﻿Imports System.ComponentModel

Public Class Customers
    Private Sub Customers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'SkiCorporationDataSet.States' table. You can move, or remove it, as needed.
        Me.StatesTableAdapter.Fill(Me.SkiCorporationDataSet.States)
        'TODO: This line of code loads data into the 'SkiCorporationDataSet.Customer' table. You can move, or remove it, as needed.
        Me.CustomerTableAdapter.FillBy1(Me.SkiCorporationDataSet.Customer)
        lblCustElig.Text = "Pass Eligibility:"
        lblCustElig.BackColor = Color.LightSteelBlue
    End Sub

    Private Sub FillByToolStripButton_Click(sender As Object, e As EventArgs) Handles FillByToolStripButton.Click
        Try
            Me.CustomerTableAdapter.FillBy(Me.SkiCorporationDataSet.Customer, LastNameToolStripTextBox.Text)
            lblCustElig.Text = "Pass Eligibility:"
            lblCustElig.BackColor = Color.LightSteelBlue
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        Try
            Me.CustomerTableAdapter.FillBy1(Me.SkiCorporationDataSet.Customer)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Function CustEmail(ByVal email As String) As String
        Dim stringInt As Integer
        Dim EmailSubString As String
        Dim LenEmail As Integer

        LenEmail = 10
        stringInt = 16
        'check if email is entered
        If email Is Nothing Then
            Return "Please enter an Email"
        Else
            'if entered determine what final four characters are 
            LenEmail = Len(email)
            stringInt = LenEmail - 4
            EmailSubString = email.Substring(stringInt)
            'Set boolean like value determinig whether a customer has a .edu email
            If EmailSubString Like ".edu" Then
                Return 1
            Else
                Return 0

            End If
        End If
    End Function

    Private Sub btnPassElig_Click(sender As Object, e As EventArgs) Handles btnPassElig.Click
        Dim CustAge As Integer
        CustAge = DateDiff(DateInterval.Year, CustomerDOBDateTimePicker.Value, Today)
        lblCustElig.Text = CustAge.ToString("###")
        If (CustAge < 12) Then
            lblCustElig.Text = "Pass Eligibility: Eligible for youth pass"
            lblCustElig.BackColor = Color.LawnGreen
        ElseIf (CustAge >= 12) And (CustAge < 18) Then
            lblCustElig.Text = "Pass Eligibility: Eligible for High School Pass"
            lblCustElig.BackColor = Color.LawnGreen
        ElseIf (CustAge >= 18) And (CustAge < 23) And CustEmail(txtCustomerEmail.Text) = 1 Then
            lblCustElig.Text = "Pass Eligibility: Potentially eligbile for college pass"
            lblCustElig.BackColor = Color.LawnGreen
        ElseIf (CustAge >= 18) And (CustAge < 60) Then
            lblCustElig.Text = "Pass Eligibility: Not eligible for price discount"
            lblCustElig.BackColor = Color.Red
        ElseIf (CustAge >= 60) Then
            lblCustElig.Text = "Pass Eligibility: Eligible for senior pass"
            lblCustElig.BackColor = Color.LawnGreen
        End If
    End Sub

    Private Sub BindingNavigatorMoveNextItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorMoveNextItem.Click
        lblCustElig.Text = "Pass Eligibility:"
        lblCustElig.BackColor = Color.LightSteelBlue
    End Sub

    Private Sub btnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
        Me.OpenFileDialog1.Title = "Get Customer Photo"
        Me.OpenFileDialog1.ShowDialog()

    End Sub

    Private Sub OpenFileDialog1_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk
        txtFileName.Text = OpenFileDialog1.FileName
    End Sub

    Private Sub btnUpload_Click(sender As Object, e As EventArgs) Handles btnUpload.Click
        If (txtFileName.Text.Trim() <> "") Then CustomerPhoto1PictureBox.Image = Image.FromFile(txtFileName.Text)
    End Sub

    Private Sub btnRemovePhoto_Click(sender As Object, e As EventArgs) Handles btnRemovePhoto.Click
        CustomerPhoto1PictureBox.Image = Nothing
    End Sub
    Dim IsAdding As Boolean = False
    Private Sub BindingNavigatorAddNewItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorAddNewItem.Click
        IsAdding = True
    End Sub

    Private Sub CustomerBindingSource_CurrentItemChanged(sender As Object, e As EventArgs) Handles CustomerBindingSource.CurrentItemChanged
        If (IsAdding) Then
            Try
                Dim cmd As New Data.SqlClient.SqlCommand
                cmd.CommandText = "SELECT Max(CustomerID) AS MaxID FROM [Customer]"
                cmd.CommandType = CommandType.Text
                cmd.Connection = Me.CustomerTableAdapter.Connection
                Dim i As Integer
                cmd.Connection.Open()
                i = cmd.ExecuteScalar() + 1
                cmd.Connection.Close()
                Me.CustomerIDTextBox.Text = i.ToString
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub



    Private Sub CustomerBindingSource_PositionChanged(sender As Object, e As EventArgs) Handles CustomerBindingSource.PositionChanged
        Try
            Dim CustAge As Integer
            CustAge = DateDiff(DateInterval.Year, CustomerDOBDateTimePicker.Value, Today)
            lblCustElig.Text = CustAge.ToString("###")
            If (CustAge < 12) Then
                lblCustElig.Text = "Pass Eligibility: Eligible for youth pass"
                lblCustElig.BackColor = Color.LawnGreen
            ElseIf (CustAge >= 12) And (CustAge < 18) Then
                lblCustElig.Text = "Pass Eligibility: Eligible for High School Pass"
                lblCustElig.BackColor = Color.LawnGreen
            ElseIf (CustAge >= 18) And (CustAge < 23) And CustEmail(txtCustomerEmail.Text) = 1 Then
                lblCustElig.Text = "Pass Eligibility: Potentially eligbile for college pass"
                lblCustElig.BackColor = Color.LawnGreen
            ElseIf (CustAge >= 18) And (CustAge < 60) Then
                lblCustElig.Text = "Pass Eligibility: Not eligible for price discount"
                lblCustElig.BackColor = Color.Red
            ElseIf (CustAge >= 60) Then
                lblCustElig.Text = "Pass Eligibility: Eligible for senior pass"
                lblCustElig.BackColor = Color.LawnGreen
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub CustomerBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles CustomerBindingNavigatorSaveItem.Click
        Try
            Me.Validate()
            Me.CustomerBindingSource.EndEdit()
            Me.CustomerTableAdapter.Update(Me.SkiCorporationDataSet.Customer)
        Catch ex As Exception
            MsgBox(ex.Message, , "Unable to save customer")
        End Try


    End Sub

    Private Sub CustomerDOBDateTimePicker_Validating(sender As Object, e As CancelEventArgs) Handles CustomerDOBDateTimePicker.Validating
        If CType(CustomerDOBDateTimePicker.Text, DateTime) > Today Then
            MsgBox("Date of Birth must be today or earlier")
            e.Cancel = True
        End If

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class