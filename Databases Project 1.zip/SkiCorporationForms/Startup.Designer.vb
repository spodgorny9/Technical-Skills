﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Startup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Startup))
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnCustomers = New System.Windows.Forms.Button()
        Me.btnRegion = New System.Windows.Forms.Button()
        Me.btnResVis = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FormsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResortVisitorsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchResortsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SkiCorporationWebsiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReadMeFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(111, 68)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(581, 29)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "Ski Corporation Information Management System"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 259)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(195, 29)
        Me.Label1.TabIndex = 34
        Me.Label1.Text = "Ski Corporation"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(713, 42)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 35
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnCustomers
        '
        Me.btnCustomers.Location = New System.Drawing.Point(40, 33)
        Me.btnCustomers.Name = "btnCustomers"
        Me.btnCustomers.Size = New System.Drawing.Size(131, 31)
        Me.btnCustomers.TabIndex = 36
        Me.btnCustomers.Text = "Customers"
        Me.btnCustomers.UseVisualStyleBackColor = True
        '
        'btnRegion
        '
        Me.btnRegion.Location = New System.Drawing.Point(40, 70)
        Me.btnRegion.Name = "btnRegion"
        Me.btnRegion.Size = New System.Drawing.Size(131, 31)
        Me.btnRegion.TabIndex = 37
        Me.btnRegion.Text = "Region"
        Me.btnRegion.UseVisualStyleBackColor = True
        '
        'btnResVis
        '
        Me.btnResVis.Location = New System.Drawing.Point(40, 107)
        Me.btnResVis.Name = "btnResVis"
        Me.btnResVis.Size = New System.Drawing.Size(131, 31)
        Me.btnResVis.TabIndex = 38
        Me.btnResVis.Text = "Resort Visitors"
        Me.btnResVis.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(40, 144)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(131, 31)
        Me.btnSearch.TabIndex = 39
        Me.btnSearch.Text = "Search Resorts"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnSearch)
        Me.GroupBox1.Controls.Add(Me.btnResVis)
        Me.GroupBox1.Controls.Add(Me.btnRegion)
        Me.GroupBox1.Controls.Add(Me.btnCustomers)
        Me.GroupBox1.Location = New System.Drawing.Point(292, 116)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(225, 209)
        Me.GroupBox1.TabIndex = 40
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Forms"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FormsToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 28)
        Me.MenuStrip1.TabIndex = 41
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FormsToolStripMenuItem
        '
        Me.FormsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomersToolStripMenuItem, Me.RegionToolStripMenuItem, Me.ResortVisitorsToolStripMenuItem, Me.SearchResortsToolStripMenuItem})
        Me.FormsToolStripMenuItem.Name = "FormsToolStripMenuItem"
        Me.FormsToolStripMenuItem.Size = New System.Drawing.Size(63, 24)
        Me.FormsToolStripMenuItem.Text = "Forms"
        '
        'CustomersToolStripMenuItem
        '
        Me.CustomersToolStripMenuItem.Name = "CustomersToolStripMenuItem"
        Me.CustomersToolStripMenuItem.Size = New System.Drawing.Size(188, 26)
        Me.CustomersToolStripMenuItem.Text = "Customers"
        '
        'RegionToolStripMenuItem
        '
        Me.RegionToolStripMenuItem.Name = "RegionToolStripMenuItem"
        Me.RegionToolStripMenuItem.Size = New System.Drawing.Size(188, 26)
        Me.RegionToolStripMenuItem.Text = "Region"
        '
        'ResortVisitorsToolStripMenuItem
        '
        Me.ResortVisitorsToolStripMenuItem.Name = "ResortVisitorsToolStripMenuItem"
        Me.ResortVisitorsToolStripMenuItem.Size = New System.Drawing.Size(188, 26)
        Me.ResortVisitorsToolStripMenuItem.Text = "Resort Visitors"
        '
        'SearchResortsToolStripMenuItem
        '
        Me.SearchResortsToolStripMenuItem.Name = "SearchResortsToolStripMenuItem"
        Me.SearchResortsToolStripMenuItem.Size = New System.Drawing.Size(188, 26)
        Me.SearchResortsToolStripMenuItem.Text = "Search Resorts"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SkiCorporationWebsiteToolStripMenuItem, Me.ReadMeFileToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(59, 24)
        Me.HelpToolStripMenuItem.Text = " Help"
        '
        'SkiCorporationWebsiteToolStripMenuItem
        '
        Me.SkiCorporationWebsiteToolStripMenuItem.Name = "SkiCorporationWebsiteToolStripMenuItem"
        Me.SkiCorporationWebsiteToolStripMenuItem.Size = New System.Drawing.Size(252, 26)
        Me.SkiCorporationWebsiteToolStripMenuItem.Text = "Ski Corporation Website"
        '
        'ReadMeFileToolStripMenuItem
        '
        Me.ReadMeFileToolStripMenuItem.Name = "ReadMeFileToolStripMenuItem"
        Me.ReadMeFileToolStripMenuItem.Size = New System.Drawing.Size(252, 26)
        Me.ReadMeFileToolStripMenuItem.Text = "Read Me File"
        '
        'PictureBox2
        '
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(12, 259)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(383, 228)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 42
        Me.PictureBox2.TabStop = False
        '
        'Startup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(800, 499)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.PictureBox2)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Startup"
        Me.Text = "Startup"
        Me.GroupBox1.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnCustomers As Button
    Friend WithEvents btnRegion As Button
    Friend WithEvents btnResVis As Button
    Friend WithEvents btnSearch As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FormsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CustomersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RegionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResortVisitorsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SearchResortsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SkiCorporationWebsiteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReadMeFileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PictureBox2 As PictureBox
End Class
