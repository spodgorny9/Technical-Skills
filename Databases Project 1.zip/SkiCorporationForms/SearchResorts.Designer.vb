﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SearchResorts
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SearchResorts))
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.cboRegion = New System.Windows.Forms.ComboBox()
        Me.DistinctRegionsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SkiCorporationDataSet = New SkiCorporationForms.SkiCorporationDataSet()
        Me.DistinctRegions = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.DistinctRegions()
        Me.lblRegion = New System.Windows.Forms.Label()
        Me.grpSnow = New System.Windows.Forms.GroupBox()
        Me.radSnow350 = New System.Windows.Forms.RadioButton()
        Me.radSnow300 = New System.Windows.Forms.RadioButton()
        Me.radSnow250 = New System.Windows.Forms.RadioButton()
        Me.radSnow200 = New System.Windows.Forms.RadioButton()
        Me.radSnow150 = New System.Windows.Forms.RadioButton()
        Me.txtMinSize = New System.Windows.Forms.TextBox()
        Me.txtMaxSize = New System.Windows.Forms.TextBox()
        Me.lblMinSize = New System.Windows.Forms.Label()
        Me.lblMaxSize = New System.Windows.Forms.Label()
        Me.txtMinLifts = New System.Windows.Forms.TextBox()
        Me.txtMaxLifts = New System.Windows.Forms.TextBox()
        Me.lblMinLifts = New System.Windows.Forms.Label()
        Me.lblMaxLifts = New System.Windows.Forms.Label()
        Me.SearchResortsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SearchResortsTableAdapter = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.SearchResortsTableAdapter()
        Me.TableAdapterManager = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.TableAdapterManager()
        Me.SearchResortsBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.SearchResortsBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.SearchResortsDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AvgSnowfall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ResortSize = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.lblSize = New System.Windows.Forms.Label()
        Me.lblAvgSnowfall = New System.Windows.Forms.Label()
        Me.lblCount = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblSizeTitle = New System.Windows.Forms.Label()
        Me.lblAvgSnowTitle = New System.Windows.Forms.Label()
        Me.cbxRegion = New System.Windows.Forms.CheckBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FormsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResortVisitorsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchResortsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SkiCorporationWebsiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReadMeFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.DistinctRegionsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SkiCorporationDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpSnow.SuspendLayout()
        CType(Me.SearchResortsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SearchResortsBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SearchResortsBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SearchResortsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(434, 62)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(192, 29)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "Search Resorts"
        '
        'cboRegion
        '
        Me.cboRegion.DataSource = Me.DistinctRegionsBindingSource
        Me.cboRegion.DisplayMember = "RegionName"
        Me.cboRegion.FormattingEnabled = True
        Me.cboRegion.Location = New System.Drawing.Point(631, 126)
        Me.cboRegion.Name = "cboRegion"
        Me.cboRegion.Size = New System.Drawing.Size(175, 24)
        Me.cboRegion.TabIndex = 1
        Me.cboRegion.ValueMember = "RegionName"
        '
        'DistinctRegionsBindingSource
        '
        Me.DistinctRegionsBindingSource.DataMember = "DistinctRegions"
        Me.DistinctRegionsBindingSource.DataSource = Me.SkiCorporationDataSet
        '
        'SkiCorporationDataSet
        '
        Me.SkiCorporationDataSet.DataSetName = "SkiCorporationDataSet"
        Me.SkiCorporationDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DistinctRegions
        '
        Me.DistinctRegions.ClearBeforeFill = True
        '
        'lblRegion
        '
        Me.lblRegion.AutoSize = True
        Me.lblRegion.Location = New System.Drawing.Point(568, 126)
        Me.lblRegion.Name = "lblRegion"
        Me.lblRegion.Size = New System.Drawing.Size(57, 17)
        Me.lblRegion.TabIndex = 2
        Me.lblRegion.Text = "Region:"
        '
        'grpSnow
        '
        Me.grpSnow.Controls.Add(Me.radSnow350)
        Me.grpSnow.Controls.Add(Me.radSnow300)
        Me.grpSnow.Controls.Add(Me.radSnow250)
        Me.grpSnow.Controls.Add(Me.radSnow200)
        Me.grpSnow.Controls.Add(Me.radSnow150)
        Me.grpSnow.Location = New System.Drawing.Point(571, 172)
        Me.grpSnow.Name = "grpSnow"
        Me.grpSnow.Size = New System.Drawing.Size(235, 173)
        Me.grpSnow.TabIndex = 3
        Me.grpSnow.TabStop = False
        Me.grpSnow.Text = "Average Annual Snowfall (inches)"
        '
        'radSnow350
        '
        Me.radSnow350.AutoSize = True
        Me.radSnow350.Location = New System.Drawing.Point(7, 146)
        Me.radSnow350.Name = "radSnow350"
        Me.radSnow350.Size = New System.Drawing.Size(61, 21)
        Me.radSnow350.TabIndex = 4
        Me.radSnow350.Tag = "350"
        Me.radSnow350.Text = ">350"
        Me.radSnow350.UseVisualStyleBackColor = True
        '
        'radSnow300
        '
        Me.radSnow300.AutoSize = True
        Me.radSnow300.Location = New System.Drawing.Point(7, 118)
        Me.radSnow300.Name = "radSnow300"
        Me.radSnow300.Size = New System.Drawing.Size(61, 21)
        Me.radSnow300.TabIndex = 3
        Me.radSnow300.Tag = "300"
        Me.radSnow300.Text = ">300"
        Me.radSnow300.UseVisualStyleBackColor = True
        '
        'radSnow250
        '
        Me.radSnow250.AutoSize = True
        Me.radSnow250.Location = New System.Drawing.Point(7, 90)
        Me.radSnow250.Name = "radSnow250"
        Me.radSnow250.Size = New System.Drawing.Size(61, 21)
        Me.radSnow250.TabIndex = 2
        Me.radSnow250.Tag = "250"
        Me.radSnow250.Text = ">250"
        Me.radSnow250.UseVisualStyleBackColor = True
        '
        'radSnow200
        '
        Me.radSnow200.AutoSize = True
        Me.radSnow200.Location = New System.Drawing.Point(7, 62)
        Me.radSnow200.Name = "radSnow200"
        Me.radSnow200.Size = New System.Drawing.Size(61, 21)
        Me.radSnow200.TabIndex = 1
        Me.radSnow200.Tag = "200"
        Me.radSnow200.Text = ">200"
        Me.radSnow200.UseVisualStyleBackColor = True
        '
        'radSnow150
        '
        Me.radSnow150.AutoSize = True
        Me.radSnow150.Checked = True
        Me.radSnow150.Location = New System.Drawing.Point(7, 34)
        Me.radSnow150.Name = "radSnow150"
        Me.radSnow150.Size = New System.Drawing.Size(61, 21)
        Me.radSnow150.TabIndex = 0
        Me.radSnow150.TabStop = True
        Me.radSnow150.Tag = "150"
        Me.radSnow150.Text = ">150"
        Me.radSnow150.UseVisualStyleBackColor = True
        '
        'txtMinSize
        '
        Me.txtMinSize.Location = New System.Drawing.Point(416, 120)
        Me.txtMinSize.Name = "txtMinSize"
        Me.txtMinSize.Size = New System.Drawing.Size(100, 22)
        Me.txtMinSize.TabIndex = 4
        Me.txtMinSize.Text = "0"
        '
        'txtMaxSize
        '
        Me.txtMaxSize.Location = New System.Drawing.Point(416, 160)
        Me.txtMaxSize.Name = "txtMaxSize"
        Me.txtMaxSize.Size = New System.Drawing.Size(100, 22)
        Me.txtMaxSize.TabIndex = 5
        Me.txtMaxSize.Text = "2500"
        '
        'lblMinSize
        '
        Me.lblMinSize.AutoSize = True
        Me.lblMinSize.Location = New System.Drawing.Point(243, 120)
        Me.lblMinSize.Name = "lblMinSize"
        Me.lblMinSize.Size = New System.Drawing.Size(147, 17)
        Me.lblMinSize.TabIndex = 6
        Me.lblMinSize.Text = "Minimum Size (acres):"
        '
        'lblMaxSize
        '
        Me.lblMaxSize.AutoSize = True
        Me.lblMaxSize.Location = New System.Drawing.Point(243, 163)
        Me.lblMaxSize.Name = "lblMaxSize"
        Me.lblMaxSize.Size = New System.Drawing.Size(150, 17)
        Me.lblMaxSize.TabIndex = 7
        Me.lblMaxSize.Text = "Maximum Size (acres):"
        '
        'txtMinLifts
        '
        Me.txtMinLifts.Location = New System.Drawing.Point(416, 206)
        Me.txtMinLifts.Name = "txtMinLifts"
        Me.txtMinLifts.Size = New System.Drawing.Size(100, 22)
        Me.txtMinLifts.TabIndex = 8
        Me.txtMinLifts.Text = "0"
        '
        'txtMaxLifts
        '
        Me.txtMaxLifts.Location = New System.Drawing.Point(416, 245)
        Me.txtMaxLifts.Name = "txtMaxLifts"
        Me.txtMaxLifts.Size = New System.Drawing.Size(100, 22)
        Me.txtMaxLifts.TabIndex = 9
        Me.txtMaxLifts.Text = "50"
        '
        'lblMinLifts
        '
        Me.lblMinLifts.AutoSize = True
        Me.lblMinLifts.Location = New System.Drawing.Point(243, 206)
        Me.lblMinLifts.Name = "lblMinLifts"
        Me.lblMinLifts.Size = New System.Drawing.Size(167, 17)
        Me.lblMinLifts.TabIndex = 10
        Me.lblMinLifts.Text = "Minimum Number of Lifts:"
        '
        'lblMaxLifts
        '
        Me.lblMaxLifts.AutoSize = True
        Me.lblMaxLifts.Location = New System.Drawing.Point(243, 248)
        Me.lblMaxLifts.Name = "lblMaxLifts"
        Me.lblMaxLifts.Size = New System.Drawing.Size(170, 17)
        Me.lblMaxLifts.TabIndex = 11
        Me.lblMaxLifts.Text = "Maximum Number of Lifts:"
        '
        'SearchResortsBindingSource
        '
        Me.SearchResortsBindingSource.DataSource = Me.SkiCorporationDataSet
        Me.SearchResortsBindingSource.Position = 0
        '
        'SearchResortsTableAdapter
        '
        Me.SearchResortsTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AccommodationTableAdapter = Nothing
        Me.TableAdapterManager.AccommodationTypeTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.Connection = Nothing
        Me.TableAdapterManager.CustomerHistoryTableAdapter = Nothing
        Me.TableAdapterManager.CustomerTableAdapter = Nothing
        Me.TableAdapterManager.PassTableAdapter = Nothing
        Me.TableAdapterManager.PassTypeTableAdapter = Nothing
        Me.TableAdapterManager.RegionAccommodationTableAdapter = Nothing
        Me.TableAdapterManager.RegionTableAdapter = Nothing
        Me.TableAdapterManager.ResortPassTableAdapter = Nothing
        Me.TableAdapterManager.ResortTableAdapter = Nothing
        Me.TableAdapterManager.StatesTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = SkiCorporationForms.SkiCorporationDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'SearchResortsBindingSource1
        '
        Me.SearchResortsBindingSource1.DataSource = Me.SkiCorporationDataSet
        Me.SearchResortsBindingSource1.Position = 0
        '
        'SearchResortsBindingSource2
        '
        Me.SearchResortsBindingSource2.DataMember = "SearchResorts"
        Me.SearchResortsBindingSource2.DataSource = Me.SkiCorporationDataSet
        '
        'SearchResortsDataGridView
        '
        Me.SearchResortsDataGridView.AutoGenerateColumns = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.SearchResortsDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.SearchResortsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.SearchResortsDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.AvgSnowfall, Me.ResortSize, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7})
        Me.SearchResortsDataGridView.DataSource = Me.SearchResortsBindingSource2
        Me.SearchResortsDataGridView.Location = New System.Drawing.Point(35, 394)
        Me.SearchResortsDataGridView.Name = "SearchResortsDataGridView"
        Me.SearchResortsDataGridView.RowHeadersWidth = 51
        Me.SearchResortsDataGridView.RowTemplate.Height = 24
        Me.SearchResortsDataGridView.Size = New System.Drawing.Size(1063, 220)
        Me.SearchResortsDataGridView.TabIndex = 12
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "ResortID"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Resort ID"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 50
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "RegionName"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Region Name"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 125
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "ResortName"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Resort Name"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 125
        '
        'AvgSnowfall
        '
        Me.AvgSnowfall.DataPropertyName = "ResortAvgAnnualSnowfall"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.AvgSnowfall.DefaultCellStyle = DataGridViewCellStyle2
        Me.AvgSnowfall.HeaderText = "Average Annual Snowfall (inches)"
        Me.AvgSnowfall.MinimumWidth = 6
        Me.AvgSnowfall.Name = "AvgSnowfall"
        Me.AvgSnowfall.Width = 70
        '
        'ResortSize
        '
        Me.ResortSize.DataPropertyName = "ResortSize"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.ResortSize.DefaultCellStyle = DataGridViewCellStyle3
        Me.ResortSize.HeaderText = "Resort Size (acres)"
        Me.ResortSize.MinimumWidth = 6
        Me.ResortSize.Name = "ResortSize"
        Me.ResortSize.Width = 80
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "NumberOfLifts"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn6.DefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridViewTextBoxColumn6.HeaderText = "Number of Lifts"
        Me.DataGridViewTextBoxColumn6.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 70
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "ResortWebsite"
        Me.DataGridViewTextBoxColumn7.HeaderText = "Resort Website"
        Me.DataGridViewTextBoxColumn7.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.Width = 205
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(731, 351)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(75, 23)
        Me.btnSearch.TabIndex = 13
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'lblSize
        '
        Me.lblSize.AutoSize = True
        Me.lblSize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSize.Location = New System.Drawing.Point(502, 633)
        Me.lblSize.Name = "lblSize"
        Me.lblSize.Size = New System.Drawing.Size(18, 19)
        Me.lblSize.TabIndex = 14
        Me.lblSize.Text = "0"
        Me.lblSize.Visible = False
        '
        'lblAvgSnowfall
        '
        Me.lblAvgSnowfall.AutoSize = True
        Me.lblAvgSnowfall.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAvgSnowfall.Location = New System.Drawing.Point(819, 633)
        Me.lblAvgSnowfall.Name = "lblAvgSnowfall"
        Me.lblAvgSnowfall.Size = New System.Drawing.Size(18, 19)
        Me.lblAvgSnowfall.TabIndex = 16
        Me.lblAvgSnowfall.Text = "0"
        Me.lblAvgSnowfall.Visible = False
        '
        'lblCount
        '
        Me.lblCount.AutoSize = True
        Me.lblCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCount.Location = New System.Drawing.Point(205, 635)
        Me.lblCount.Name = "lblCount"
        Me.lblCount.Size = New System.Drawing.Size(18, 19)
        Me.lblCount.TabIndex = 19
        Me.lblCount.Text = "0"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(32, 635)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(153, 17)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "Number of Matches:"
        '
        'lblSizeTitle
        '
        Me.lblSizeTitle.AutoSize = True
        Me.lblSizeTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSizeTitle.Location = New System.Drawing.Point(293, 633)
        Me.lblSizeTitle.Name = "lblSizeTitle"
        Me.lblSizeTitle.Size = New System.Drawing.Size(184, 17)
        Me.lblSizeTitle.TabIndex = 21
        Me.lblSizeTitle.Text = "Total Inbounds Terrain: "
        Me.lblSizeTitle.Visible = False
        '
        'lblAvgSnowTitle
        '
        Me.lblAvgSnowTitle.AutoSize = True
        Me.lblAvgSnowTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAvgSnowTitle.Location = New System.Drawing.Point(661, 635)
        Me.lblAvgSnowTitle.Name = "lblAvgSnowTitle"
        Me.lblAvgSnowTitle.Size = New System.Drawing.Size(138, 17)
        Me.lblAvgSnowTitle.TabIndex = 22
        Me.lblAvgSnowTitle.Text = "Average Snowfall:"
        Me.lblAvgSnowTitle.Visible = False
        '
        'cbxRegion
        '
        Me.cbxRegion.AutoSize = True
        Me.cbxRegion.Checked = True
        Me.cbxRegion.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbxRegion.Location = New System.Drawing.Point(819, 128)
        Me.cbxRegion.Name = "cbxRegion"
        Me.cbxRegion.Size = New System.Drawing.Size(45, 21)
        Me.cbxRegion.TabIndex = 23
        Me.cbxRegion.Text = "All"
        Me.cbxRegion.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(35, 44)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(175, 93)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 24
        Me.PictureBox1.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(35, 44)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(105, 17)
        Me.Label2.TabIndex = 25
        Me.Label2.Text = "Ski Corporation"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(1023, 62)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 26
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FormsToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1121, 28)
        Me.MenuStrip1.TabIndex = 42
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FormsToolStripMenuItem
        '
        Me.FormsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomersToolStripMenuItem, Me.RegionToolStripMenuItem, Me.ResortVisitorsToolStripMenuItem, Me.SearchResortsToolStripMenuItem})
        Me.FormsToolStripMenuItem.Name = "FormsToolStripMenuItem"
        Me.FormsToolStripMenuItem.Size = New System.Drawing.Size(63, 24)
        Me.FormsToolStripMenuItem.Text = "Forms"
        '
        'CustomersToolStripMenuItem
        '
        Me.CustomersToolStripMenuItem.Name = "CustomersToolStripMenuItem"
        Me.CustomersToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.CustomersToolStripMenuItem.Text = "Customers"
        '
        'RegionToolStripMenuItem
        '
        Me.RegionToolStripMenuItem.Name = "RegionToolStripMenuItem"
        Me.RegionToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.RegionToolStripMenuItem.Text = "Region"
        '
        'ResortVisitorsToolStripMenuItem
        '
        Me.ResortVisitorsToolStripMenuItem.Name = "ResortVisitorsToolStripMenuItem"
        Me.ResortVisitorsToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.ResortVisitorsToolStripMenuItem.Text = "Resort Visitors"
        '
        'SearchResortsToolStripMenuItem
        '
        Me.SearchResortsToolStripMenuItem.Name = "SearchResortsToolStripMenuItem"
        Me.SearchResortsToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.SearchResortsToolStripMenuItem.Text = "Search Resorts"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SkiCorporationWebsiteToolStripMenuItem, Me.ReadMeFileToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(59, 24)
        Me.HelpToolStripMenuItem.Text = " Help"
        '
        'SkiCorporationWebsiteToolStripMenuItem
        '
        Me.SkiCorporationWebsiteToolStripMenuItem.Name = "SkiCorporationWebsiteToolStripMenuItem"
        Me.SkiCorporationWebsiteToolStripMenuItem.Size = New System.Drawing.Size(252, 26)
        Me.SkiCorporationWebsiteToolStripMenuItem.Text = "Ski Corporation Website"
        '
        'ReadMeFileToolStripMenuItem
        '
        Me.ReadMeFileToolStripMenuItem.Name = "ReadMeFileToolStripMenuItem"
        Me.ReadMeFileToolStripMenuItem.Size = New System.Drawing.Size(252, 26)
        Me.ReadMeFileToolStripMenuItem.Text = "Read Me File"
        '
        'SearchResorts
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(1121, 712)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.cbxRegion)
        Me.Controls.Add(Me.lblAvgSnowTitle)
        Me.Controls.Add(Me.lblSizeTitle)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblCount)
        Me.Controls.Add(Me.lblAvgSnowfall)
        Me.Controls.Add(Me.lblSize)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.SearchResortsDataGridView)
        Me.Controls.Add(Me.lblMaxLifts)
        Me.Controls.Add(Me.lblMinLifts)
        Me.Controls.Add(Me.txtMaxLifts)
        Me.Controls.Add(Me.txtMinLifts)
        Me.Controls.Add(Me.lblMaxSize)
        Me.Controls.Add(Me.lblMinSize)
        Me.Controls.Add(Me.txtMaxSize)
        Me.Controls.Add(Me.txtMinSize)
        Me.Controls.Add(Me.grpSnow)
        Me.Controls.Add(Me.lblRegion)
        Me.Controls.Add(Me.cboRegion)
        Me.Controls.Add(Me.lblTitle)
        Me.Name = "SearchResorts"
        Me.Text = "SearchResorts"
        CType(Me.DistinctRegionsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SkiCorporationDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpSnow.ResumeLayout(False)
        Me.grpSnow.PerformLayout()
        CType(Me.SearchResortsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SearchResortsBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SearchResortsBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SearchResortsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents cboRegion As ComboBox
    Friend WithEvents SkiCorporationDataSet As SkiCorporationDataSet
    Friend WithEvents DistinctRegionsBindingSource As BindingSource
    Friend WithEvents DistinctRegions As SkiCorporationDataSetTableAdapters.DistinctRegions
    Friend WithEvents lblRegion As Label
    Friend WithEvents grpSnow As GroupBox
    Friend WithEvents radSnow350 As RadioButton
    Friend WithEvents radSnow300 As RadioButton
    Friend WithEvents radSnow250 As RadioButton
    Friend WithEvents radSnow200 As RadioButton
    Friend WithEvents radSnow150 As RadioButton
    Friend WithEvents txtMinSize As TextBox
    Friend WithEvents txtMaxSize As TextBox
    Friend WithEvents lblMinSize As Label
    Friend WithEvents lblMaxSize As Label
    Friend WithEvents txtMinLifts As TextBox
    Friend WithEvents txtMaxLifts As TextBox
    Friend WithEvents lblMinLifts As Label
    Friend WithEvents lblMaxLifts As Label
    Friend WithEvents SearchResortsBindingSource As BindingSource
    Friend WithEvents SearchResortsTableAdapter As SkiCorporationDataSetTableAdapters.SearchResortsTableAdapter
    Friend WithEvents TableAdapterManager As SkiCorporationDataSetTableAdapters.TableAdapterManager
    Friend WithEvents SearchResortsBindingSource1 As BindingSource
    Friend WithEvents SearchResortsBindingSource2 As BindingSource
    Friend WithEvents SearchResortsDataGridView As DataGridView
    Friend WithEvents btnSearch As Button
    Friend WithEvents lblSize As Label
    Friend WithEvents lblAvgSnowfall As Label
    Friend WithEvents lblCount As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lblSizeTitle As Label
    Friend WithEvents lblAvgSnowTitle As Label
    Friend WithEvents cbxRegion As CheckBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents AvgSnowfall As DataGridViewTextBoxColumn
    Friend WithEvents ResortSize As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents btnExit As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FormsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CustomersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RegionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResortVisitorsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SearchResortsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SkiCorporationWebsiteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReadMeFileToolStripMenuItem As ToolStripMenuItem
End Class
