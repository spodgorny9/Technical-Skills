﻿Public Class Startup
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCustomers_Click(sender As Object, e As EventArgs) Handles btnCustomers.Click
        Try
            Dim frmCustomers As New Customers
            frmCustomers.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnRegion_Click(sender As Object, e As EventArgs) Handles btnRegion.Click
        Try
            Dim frmRegion As New Region
            frmRegion.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnResVis_Click(sender As Object, e As EventArgs) Handles btnResVis.Click
        Try
            Dim frmResortVisitors As New ResortVisitors
            frmResortVisitors.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Try
            Dim frmSearch As New SearchResorts
            frmSearch.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub CustomersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CustomersToolStripMenuItem.Click
        Try
            Dim frmCustomers As New Customers
            frmCustomers.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub RegionToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegionToolStripMenuItem.Click
        Try
            Dim frmRegion As New Region
            frmRegion.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ResortVisitorsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResortVisitorsToolStripMenuItem.Click
        Try
            Dim frmResortVisitors As New ResortVisitors
            frmResortVisitors.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub SearchResortsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchResortsToolStripMenuItem.Click
        Try
            Dim frmSearch As New SearchResorts
            frmSearch.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ReadMeFileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ReadMeFileToolStripMenuItem.Click
        Try
            Dim frmReadMe As New ReadMe
            frmReadMe.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class