﻿Partial Class SkiCorporationDataSet
    Partial Public Class ResortDataTable
    End Class

    Partial Public Class CustomerDataTable

    End Class
End Class

Namespace SkiCorporationDataSetTableAdapters

    Partial Public Class ResortTableAdapter
    End Class
End Namespace
