﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ResortVisitors
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ResortIDLabel As System.Windows.Forms.Label
        Dim ResortNameLabel As System.Windows.Forms.Label
        Dim ResortAvgAnnualSnowfallLabel As System.Windows.Forms.Label
        Dim ResortSizeLabel As System.Windows.Forms.Label
        Dim NumberOfLiftsLabel As System.Windows.Forms.Label
        Dim ResortWebsiteLabel As System.Windows.Forms.Label
        Dim RegionIDLabel As System.Windows.Forms.Label
        Dim IndustryAvgSnowLabel As System.Windows.Forms.Label
        Dim IndustryAvgSizeLabel As System.Windows.Forms.Label
        Dim IndustryAvgVisitorsLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ResortVisitors))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.SkiCorporationDataSet = New SkiCorporationForms.SkiCorporationDataSet()
        Me.ResortBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ResortTableAdapter = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.ResortTableAdapter()
        Me.TableAdapterManager = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.TableAdapterManager()
        Me.CustomerHistoryTableAdapter = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.CustomerHistoryTableAdapter()
        Me.CustomerTableAdapter = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.CustomerTableAdapter()
        Me.ResortBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ResortBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.ResortIDTextBox = New System.Windows.Forms.TextBox()
        Me.ResortNameTextBox = New System.Windows.Forms.TextBox()
        Me.ResortWebsiteTextBox = New System.Windows.Forms.TextBox()
        Me.CustomerHistoryBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CustomerHistoryDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.CustomerNamesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SkiCorporationDataSet1 = New SkiCorporationForms.SkiCorporationDataSet()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AttenDuration = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustomerBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CustomerNamesTableAdapter = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.CustomerNamesTableAdapter()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.RegionIDComboBox = New System.Windows.Forms.ComboBox()
        Me.RegionBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.ResortBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.RegionBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.RegionTableAdapter = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.RegionTableAdapter()
        Me.lblCount = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ResortBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.AvgSnowFallBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.AvgSnowFallTableAdapter = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.AvgSnowFallTableAdapter()
        Me.IndustryAvgSnowTextBox = New System.Windows.Forms.TextBox()
        Me.AvgSizeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.AvgSizeTableAdapter = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.AvgSizeTableAdapter()
        Me.IndustryAvgSizeTextBox = New System.Windows.Forms.TextBox()
        Me.AvgNumVisitorsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.AvgNumVisitorsTableAdapter = New SkiCorporationForms.SkiCorporationDataSetTableAdapters.AvgNumVisitorsTableAdapter()
        Me.IndustryAvgVisitorsTextBox = New System.Windows.Forms.TextBox()
        Me.lblResortAnalysis = New System.Windows.Forms.Label()
        Me.btnResAnalysis = New System.Windows.Forms.Button()
        Me.lblAvgDuration = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.AvgSnowMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.SizeMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.LiftsMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FormsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResortVisitorsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchResortsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SkiCorporationWebsiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReadMeFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        ResortIDLabel = New System.Windows.Forms.Label()
        ResortNameLabel = New System.Windows.Forms.Label()
        ResortAvgAnnualSnowfallLabel = New System.Windows.Forms.Label()
        ResortSizeLabel = New System.Windows.Forms.Label()
        NumberOfLiftsLabel = New System.Windows.Forms.Label()
        ResortWebsiteLabel = New System.Windows.Forms.Label()
        RegionIDLabel = New System.Windows.Forms.Label()
        IndustryAvgSnowLabel = New System.Windows.Forms.Label()
        IndustryAvgSizeLabel = New System.Windows.Forms.Label()
        IndustryAvgVisitorsLabel = New System.Windows.Forms.Label()
        CType(Me.SkiCorporationDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResortBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResortBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ResortBindingNavigator.SuspendLayout()
        CType(Me.CustomerHistoryBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerHistoryDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerNamesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SkiCorporationDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RegionBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResortBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RegionBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResortBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AvgSnowFallBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AvgSizeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AvgNumVisitorsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ResortIDLabel
        '
        ResortIDLabel.AutoSize = True
        ResortIDLabel.Location = New System.Drawing.Point(72, 149)
        ResortIDLabel.Name = "ResortIDLabel"
        ResortIDLabel.Size = New System.Drawing.Size(71, 17)
        ResortIDLabel.TabIndex = 1
        ResortIDLabel.Text = "Resort ID:"
        '
        'ResortNameLabel
        '
        ResortNameLabel.AutoSize = True
        ResortNameLabel.Location = New System.Drawing.Point(72, 205)
        ResortNameLabel.Name = "ResortNameLabel"
        ResortNameLabel.Size = New System.Drawing.Size(95, 17)
        ResortNameLabel.TabIndex = 5
        ResortNameLabel.Text = "Resort Name:"
        '
        'ResortAvgAnnualSnowfallLabel
        '
        ResortAvgAnnualSnowfallLabel.AutoSize = True
        ResortAvgAnnualSnowfallLabel.Location = New System.Drawing.Point(72, 233)
        ResortAvgAnnualSnowfallLabel.Name = "ResortAvgAnnualSnowfallLabel"
        ResortAvgAnnualSnowfallLabel.Size = New System.Drawing.Size(186, 17)
        ResortAvgAnnualSnowfallLabel.TabIndex = 7
        ResortAvgAnnualSnowfallLabel.Text = "Resort Avg Annual Snowfall:"
        '
        'ResortSizeLabel
        '
        ResortSizeLabel.AutoSize = True
        ResortSizeLabel.Location = New System.Drawing.Point(379, 146)
        ResortSizeLabel.Name = "ResortSizeLabel"
        ResortSizeLabel.Size = New System.Drawing.Size(85, 17)
        ResortSizeLabel.TabIndex = 9
        ResortSizeLabel.Text = "Resort Size:"
        '
        'NumberOfLiftsLabel
        '
        NumberOfLiftsLabel.AutoSize = True
        NumberOfLiftsLabel.Location = New System.Drawing.Point(379, 174)
        NumberOfLiftsLabel.Name = "NumberOfLiftsLabel"
        NumberOfLiftsLabel.Size = New System.Drawing.Size(111, 17)
        NumberOfLiftsLabel.TabIndex = 11
        NumberOfLiftsLabel.Text = "Number Of Lifts:"
        '
        'ResortWebsiteLabel
        '
        ResortWebsiteLabel.AutoSize = True
        ResortWebsiteLabel.Location = New System.Drawing.Point(379, 202)
        ResortWebsiteLabel.Name = "ResortWebsiteLabel"
        ResortWebsiteLabel.Size = New System.Drawing.Size(109, 17)
        ResortWebsiteLabel.TabIndex = 13
        ResortWebsiteLabel.Text = "Resort Website:"
        '
        'RegionIDLabel
        '
        RegionIDLabel.AutoSize = True
        RegionIDLabel.Location = New System.Drawing.Point(72, 177)
        RegionIDLabel.Name = "RegionIDLabel"
        RegionIDLabel.Size = New System.Drawing.Size(57, 17)
        RegionIDLabel.TabIndex = 16
        RegionIDLabel.Text = "Region:"
        '
        'IndustryAvgSnowLabel
        '
        IndustryAvgSnowLabel.AutoSize = True
        IndustryAvgSnowLabel.Location = New System.Drawing.Point(558, 591)
        IndustryAvgSnowLabel.Name = "IndustryAvgSnowLabel"
        IndustryAvgSnowLabel.Size = New System.Drawing.Size(128, 17)
        IndustryAvgSnowLabel.TabIndex = 21
        IndustryAvgSnowLabel.Text = "Industry Avg Snow:"
        '
        'IndustryAvgSizeLabel
        '
        IndustryAvgSizeLabel.AutoSize = True
        IndustryAvgSizeLabel.Location = New System.Drawing.Point(313, 591)
        IndustryAvgSizeLabel.Name = "IndustryAvgSizeLabel"
        IndustryAvgSizeLabel.Size = New System.Drawing.Size(121, 17)
        IndustryAvgSizeLabel.TabIndex = 23
        IndustryAvgSizeLabel.Text = "Industry Avg Size:"
        '
        'IndustryAvgVisitorsLabel
        '
        IndustryAvgVisitorsLabel.AutoSize = True
        IndustryAvgVisitorsLabel.Location = New System.Drawing.Point(57, 593)
        IndustryAvgVisitorsLabel.Name = "IndustryAvgVisitorsLabel"
        IndustryAvgVisitorsLabel.Size = New System.Drawing.Size(140, 17)
        IndustryAvgVisitorsLabel.TabIndex = 25
        IndustryAvgVisitorsLabel.Text = "Industry Avg Visitors:"
        '
        'SkiCorporationDataSet
        '
        Me.SkiCorporationDataSet.DataSetName = "SkiCorporationDataSet"
        Me.SkiCorporationDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ResortBindingSource
        '
        Me.ResortBindingSource.DataMember = "Resort"
        Me.ResortBindingSource.DataSource = Me.SkiCorporationDataSet
        '
        'ResortTableAdapter
        '
        Me.ResortTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AccommodationTableAdapter = Nothing
        Me.TableAdapterManager.AccommodationTypeTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CustomerHistoryTableAdapter = Me.CustomerHistoryTableAdapter
        Me.TableAdapterManager.CustomerTableAdapter = Me.CustomerTableAdapter
        Me.TableAdapterManager.PassTableAdapter = Nothing
        Me.TableAdapterManager.PassTypeTableAdapter = Nothing
        Me.TableAdapterManager.RegionAccommodationTableAdapter = Nothing
        Me.TableAdapterManager.RegionTableAdapter = Nothing
        Me.TableAdapterManager.ResortPassTableAdapter = Nothing
        Me.TableAdapterManager.ResortTableAdapter = Me.ResortTableAdapter
        Me.TableAdapterManager.StatesTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = SkiCorporationForms.SkiCorporationDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'CustomerHistoryTableAdapter
        '
        Me.CustomerHistoryTableAdapter.ClearBeforeFill = True
        '
        'CustomerTableAdapter
        '
        Me.CustomerTableAdapter.ClearBeforeFill = True
        '
        'ResortBindingNavigator
        '
        Me.ResortBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.ResortBindingNavigator.BindingSource = Me.ResortBindingSource
        Me.ResortBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.ResortBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.ResortBindingNavigator.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ResortBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.ResortBindingNavigatorSaveItem})
        Me.ResortBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.ResortBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.ResortBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.ResortBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.ResortBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.ResortBindingNavigator.Name = "ResortBindingNavigator"
        Me.ResortBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.ResortBindingNavigator.Size = New System.Drawing.Size(916, 27)
        Me.ResortBindingNavigator.TabIndex = 0
        Me.ResortBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        Me.BindingNavigatorAddNewItem.Visible = False
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(45, 24)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Enabled = False
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        Me.BindingNavigatorDeleteItem.Visible = False
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 27)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 27)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 27)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 27)
        '
        'ResortBindingNavigatorSaveItem
        '
        Me.ResortBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ResortBindingNavigatorSaveItem.Image = CType(resources.GetObject("ResortBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.ResortBindingNavigatorSaveItem.Name = "ResortBindingNavigatorSaveItem"
        Me.ResortBindingNavigatorSaveItem.Size = New System.Drawing.Size(29, 24)
        Me.ResortBindingNavigatorSaveItem.Text = "Save Data"
        '
        'ResortIDTextBox
        '
        Me.ResortIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ResortBindingSource, "ResortID", True))
        Me.ResortIDTextBox.Location = New System.Drawing.Point(173, 146)
        Me.ResortIDTextBox.Name = "ResortIDTextBox"
        Me.ResortIDTextBox.ReadOnly = True
        Me.ResortIDTextBox.Size = New System.Drawing.Size(191, 22)
        Me.ResortIDTextBox.TabIndex = 2
        '
        'ResortNameTextBox
        '
        Me.ResortNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ResortBindingSource, "ResortName", True))
        Me.ResortNameTextBox.Location = New System.Drawing.Point(173, 202)
        Me.ResortNameTextBox.Name = "ResortNameTextBox"
        Me.ResortNameTextBox.Size = New System.Drawing.Size(191, 22)
        Me.ResortNameTextBox.TabIndex = 6
        '
        'ResortWebsiteTextBox
        '
        Me.ResortWebsiteTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ResortBindingSource, "ResortWebsite", True))
        Me.ResortWebsiteTextBox.Location = New System.Drawing.Point(494, 202)
        Me.ResortWebsiteTextBox.Name = "ResortWebsiteTextBox"
        Me.ResortWebsiteTextBox.Size = New System.Drawing.Size(255, 22)
        Me.ResortWebsiteTextBox.TabIndex = 14
        '
        'CustomerHistoryBindingSource
        '
        Me.CustomerHistoryBindingSource.DataMember = "fk_hist_resort_id"
        Me.CustomerHistoryBindingSource.DataSource = Me.ResortBindingSource
        '
        'CustomerHistoryDataGridView
        '
        Me.CustomerHistoryDataGridView.AutoGenerateColumns = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.CustomerHistoryDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.CustomerHistoryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.CustomerHistoryDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.AttenDuration})
        Me.CustomerHistoryDataGridView.DataSource = Me.CustomerHistoryBindingSource
        Me.CustomerHistoryDataGridView.Location = New System.Drawing.Point(75, 286)
        Me.CustomerHistoryDataGridView.Name = "CustomerHistoryDataGridView"
        Me.CustomerHistoryDataGridView.RowHeadersWidth = 51
        Me.CustomerHistoryDataGridView.RowTemplate.Height = 24
        Me.CustomerHistoryDataGridView.Size = New System.Drawing.Size(761, 220)
        Me.CustomerHistoryDataGridView.TabIndex = 15
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "VisitID"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Visit ID"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 125
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "CustomerID"
        Me.DataGridViewTextBoxColumn3.DataSource = Me.CustomerNamesBindingSource
        Me.DataGridViewTextBoxColumn3.DisplayMember = "CustomerFullName"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Customer Name"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn3.ValueMember = "CustomerID"
        Me.DataGridViewTextBoxColumn3.Width = 125
        '
        'CustomerNamesBindingSource
        '
        Me.CustomerNamesBindingSource.DataMember = "CustomerNames"
        Me.CustomerNamesBindingSource.DataSource = Me.SkiCorporationDataSet1
        '
        'SkiCorporationDataSet1
        '
        Me.SkiCorporationDataSet1.DataSetName = "SkiCorporationDataSet"
        Me.SkiCorporationDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "AttendanceDate"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn4.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridViewTextBoxColumn4.HeaderText = "Attendance Date"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 125
        '
        'AttenDuration
        '
        Me.AttenDuration.DataPropertyName = "AttendanceDuration"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.AttenDuration.DefaultCellStyle = DataGridViewCellStyle3
        Me.AttenDuration.HeaderText = "Attendance Duration"
        Me.AttenDuration.MinimumWidth = 6
        Me.AttenDuration.Name = "AttenDuration"
        Me.AttenDuration.Width = 125
        '
        'CustomerBindingSource
        '
        Me.CustomerBindingSource.DataMember = "Customer"
        Me.CustomerBindingSource.DataSource = Me.SkiCorporationDataSet
        '
        'CustomerNamesTableAdapter
        '
        Me.CustomerNamesTableAdapter.ClearBeforeFill = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(345, 102)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(160, 29)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Resort Visits"
        '
        'RegionIDComboBox
        '
        Me.RegionIDComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.ResortBindingSource, "RegionName", True))
        Me.RegionIDComboBox.DataSource = Me.RegionBindingSource1
        Me.RegionIDComboBox.DisplayMember = "RegionName"
        Me.RegionIDComboBox.FormattingEnabled = True
        Me.RegionIDComboBox.Location = New System.Drawing.Point(173, 174)
        Me.RegionIDComboBox.Name = "RegionIDComboBox"
        Me.RegionIDComboBox.Size = New System.Drawing.Size(191, 24)
        Me.RegionIDComboBox.TabIndex = 17
        Me.RegionIDComboBox.ValueMember = "RegionName"
        '
        'RegionBindingSource1
        '
        Me.RegionBindingSource1.DataMember = "Region"
        Me.RegionBindingSource1.DataSource = Me.SkiCorporationDataSet
        '
        'ResortBindingSource1
        '
        Me.ResortBindingSource1.DataMember = "Resort"
        Me.ResortBindingSource1.DataSource = Me.SkiCorporationDataSet
        '
        'RegionBindingSource
        '
        Me.RegionBindingSource.DataMember = "Region"
        Me.RegionBindingSource.DataSource = Me.SkiCorporationDataSet
        '
        'RegionTableAdapter
        '
        Me.RegionTableAdapter.ClearBeforeFill = True
        '
        'lblCount
        '
        Me.lblCount.AutoSize = True
        Me.lblCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCount.Location = New System.Drawing.Point(785, 552)
        Me.lblCount.Name = "lblCount"
        Me.lblCount.Size = New System.Drawing.Size(18, 19)
        Me.lblCount.TabIndex = 18
        Me.lblCount.Text = "0"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(649, 552)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(94, 17)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "Total Visits:"
        '
        'ResortBindingSource2
        '
        Me.ResortBindingSource2.DataMember = "Resort"
        Me.ResortBindingSource2.DataSource = Me.SkiCorporationDataSet
        '
        'PictureBox1
        '
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(75, 65)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(181, 79)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 20
        Me.PictureBox1.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Location = New System.Drawing.Point(72, 65)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(105, 17)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "Ski Corporation"
        '
        'AvgSnowFallBindingSource
        '
        Me.AvgSnowFallBindingSource.DataMember = "AvgSnowFall"
        Me.AvgSnowFallBindingSource.DataSource = Me.SkiCorporationDataSet
        '
        'AvgSnowFallTableAdapter
        '
        Me.AvgSnowFallTableAdapter.ClearBeforeFill = True
        '
        'IndustryAvgSnowTextBox
        '
        Me.IndustryAvgSnowTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AvgSnowFallBindingSource, "IndustryAvgSnow", True))
        Me.IndustryAvgSnowTextBox.Location = New System.Drawing.Point(692, 588)
        Me.IndustryAvgSnowTextBox.Name = "IndustryAvgSnowTextBox"
        Me.IndustryAvgSnowTextBox.ReadOnly = True
        Me.IndustryAvgSnowTextBox.Size = New System.Drawing.Size(100, 22)
        Me.IndustryAvgSnowTextBox.TabIndex = 22
        Me.IndustryAvgSnowTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'AvgSizeBindingSource
        '
        Me.AvgSizeBindingSource.DataMember = "AvgSize"
        Me.AvgSizeBindingSource.DataSource = Me.SkiCorporationDataSet
        '
        'AvgSizeTableAdapter
        '
        Me.AvgSizeTableAdapter.ClearBeforeFill = True
        '
        'IndustryAvgSizeTextBox
        '
        Me.IndustryAvgSizeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AvgSizeBindingSource, "IndustryAvgSize", True))
        Me.IndustryAvgSizeTextBox.Location = New System.Drawing.Point(440, 588)
        Me.IndustryAvgSizeTextBox.Name = "IndustryAvgSizeTextBox"
        Me.IndustryAvgSizeTextBox.ReadOnly = True
        Me.IndustryAvgSizeTextBox.Size = New System.Drawing.Size(100, 22)
        Me.IndustryAvgSizeTextBox.TabIndex = 24
        Me.IndustryAvgSizeTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'AvgNumVisitorsBindingSource
        '
        Me.AvgNumVisitorsBindingSource.DataMember = "AvgNumVisitors"
        Me.AvgNumVisitorsBindingSource.DataSource = Me.SkiCorporationDataSet
        '
        'AvgNumVisitorsTableAdapter
        '
        Me.AvgNumVisitorsTableAdapter.ClearBeforeFill = True
        '
        'IndustryAvgVisitorsTextBox
        '
        Me.IndustryAvgVisitorsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AvgNumVisitorsBindingSource, "IndustryAvgVisitors", True))
        Me.IndustryAvgVisitorsTextBox.Location = New System.Drawing.Point(203, 590)
        Me.IndustryAvgVisitorsTextBox.Name = "IndustryAvgVisitorsTextBox"
        Me.IndustryAvgVisitorsTextBox.ReadOnly = True
        Me.IndustryAvgVisitorsTextBox.Size = New System.Drawing.Size(100, 22)
        Me.IndustryAvgVisitorsTextBox.TabIndex = 26
        Me.IndustryAvgVisitorsTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblResortAnalysis
        '
        Me.lblResortAnalysis.AutoSize = True
        Me.lblResortAnalysis.Location = New System.Drawing.Point(57, 552)
        Me.lblResortAnalysis.Name = "lblResortAnalysis"
        Me.lblResortAnalysis.Size = New System.Drawing.Size(0, 17)
        Me.lblResortAnalysis.TabIndex = 27
        '
        'btnResAnalysis
        '
        Me.btnResAnalysis.Location = New System.Drawing.Point(75, 512)
        Me.btnResAnalysis.Name = "btnResAnalysis"
        Me.btnResAnalysis.Size = New System.Drawing.Size(163, 30)
        Me.btnResAnalysis.TabIndex = 28
        Me.btnResAnalysis.Text = "Compare Resort"
        Me.btnResAnalysis.UseVisualStyleBackColor = True
        '
        'lblAvgDuration
        '
        Me.lblAvgDuration.AutoSize = True
        Me.lblAvgDuration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAvgDuration.Location = New System.Drawing.Point(758, 519)
        Me.lblAvgDuration.Name = "lblAvgDuration"
        Me.lblAvgDuration.Size = New System.Drawing.Size(18, 19)
        Me.lblAvgDuration.TabIndex = 29
        Me.lblAvgDuration.Text = "0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(516, 519)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(227, 17)
        Me.Label4.TabIndex = 30
        Me.Label4.Text = "Average Attendance Duration:"
        '
        'AvgSnowMaskedTextBox
        '
        Me.AvgSnowMaskedTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ResortBindingSource, "ResortAvgAnnualSnowfall", True))
        Me.AvgSnowMaskedTextBox.Location = New System.Drawing.Point(264, 233)
        Me.AvgSnowMaskedTextBox.Mask = "00000"
        Me.AvgSnowMaskedTextBox.Name = "AvgSnowMaskedTextBox"
        Me.AvgSnowMaskedTextBox.Size = New System.Drawing.Size(55, 22)
        Me.AvgSnowMaskedTextBox.TabIndex = 31
        Me.AvgSnowMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.AvgSnowMaskedTextBox.ValidatingType = GetType(Integer)
        '
        'SizeMaskedTextBox
        '
        Me.SizeMaskedTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ResortBindingSource, "ResortSize", True))
        Me.SizeMaskedTextBox.Location = New System.Drawing.Point(692, 141)
        Me.SizeMaskedTextBox.Mask = "00000"
        Me.SizeMaskedTextBox.Name = "SizeMaskedTextBox"
        Me.SizeMaskedTextBox.Size = New System.Drawing.Size(57, 22)
        Me.SizeMaskedTextBox.TabIndex = 32
        Me.SizeMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.SizeMaskedTextBox.ValidatingType = GetType(Integer)
        '
        'LiftsMaskedTextBox
        '
        Me.LiftsMaskedTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ResortBindingSource, "NumberOfLifts", True))
        Me.LiftsMaskedTextBox.Location = New System.Drawing.Point(692, 174)
        Me.LiftsMaskedTextBox.Mask = "00"
        Me.LiftsMaskedTextBox.Name = "LiftsMaskedTextBox"
        Me.LiftsMaskedTextBox.Size = New System.Drawing.Size(57, 22)
        Me.LiftsMaskedTextBox.TabIndex = 33
        Me.LiftsMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.LiftsMaskedTextBox.ValidatingType = GetType(Integer)
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(760, 102)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 34
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FormsToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 27)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(916, 28)
        Me.MenuStrip1.TabIndex = 42
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FormsToolStripMenuItem
        '
        Me.FormsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomersToolStripMenuItem, Me.RegionToolStripMenuItem, Me.ResortVisitorsToolStripMenuItem, Me.SearchResortsToolStripMenuItem})
        Me.FormsToolStripMenuItem.Name = "FormsToolStripMenuItem"
        Me.FormsToolStripMenuItem.Size = New System.Drawing.Size(63, 24)
        Me.FormsToolStripMenuItem.Text = "Forms"
        '
        'CustomersToolStripMenuItem
        '
        Me.CustomersToolStripMenuItem.Name = "CustomersToolStripMenuItem"
        Me.CustomersToolStripMenuItem.Size = New System.Drawing.Size(188, 26)
        Me.CustomersToolStripMenuItem.Text = "Customers"
        '
        'RegionToolStripMenuItem
        '
        Me.RegionToolStripMenuItem.Name = "RegionToolStripMenuItem"
        Me.RegionToolStripMenuItem.Size = New System.Drawing.Size(188, 26)
        Me.RegionToolStripMenuItem.Text = "Region"
        '
        'ResortVisitorsToolStripMenuItem
        '
        Me.ResortVisitorsToolStripMenuItem.Name = "ResortVisitorsToolStripMenuItem"
        Me.ResortVisitorsToolStripMenuItem.Size = New System.Drawing.Size(188, 26)
        Me.ResortVisitorsToolStripMenuItem.Text = "Resort Visitors"
        '
        'SearchResortsToolStripMenuItem
        '
        Me.SearchResortsToolStripMenuItem.Name = "SearchResortsToolStripMenuItem"
        Me.SearchResortsToolStripMenuItem.Size = New System.Drawing.Size(188, 26)
        Me.SearchResortsToolStripMenuItem.Text = "Search Resorts"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SkiCorporationWebsiteToolStripMenuItem, Me.ReadMeFileToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(59, 24)
        Me.HelpToolStripMenuItem.Text = " Help"
        '
        'SkiCorporationWebsiteToolStripMenuItem
        '
        Me.SkiCorporationWebsiteToolStripMenuItem.Name = "SkiCorporationWebsiteToolStripMenuItem"
        Me.SkiCorporationWebsiteToolStripMenuItem.Size = New System.Drawing.Size(252, 26)
        Me.SkiCorporationWebsiteToolStripMenuItem.Text = "Ski Corporation Website"
        '
        'ReadMeFileToolStripMenuItem
        '
        Me.ReadMeFileToolStripMenuItem.Name = "ReadMeFileToolStripMenuItem"
        Me.ReadMeFileToolStripMenuItem.Size = New System.Drawing.Size(252, 26)
        Me.ReadMeFileToolStripMenuItem.Text = "Read Me File"
        '
        'ResortVisitors
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(916, 623)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.LiftsMaskedTextBox)
        Me.Controls.Add(Me.SizeMaskedTextBox)
        Me.Controls.Add(Me.AvgSnowMaskedTextBox)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lblAvgDuration)
        Me.Controls.Add(Me.btnResAnalysis)
        Me.Controls.Add(Me.lblResortAnalysis)
        Me.Controls.Add(IndustryAvgVisitorsLabel)
        Me.Controls.Add(Me.IndustryAvgVisitorsTextBox)
        Me.Controls.Add(IndustryAvgSizeLabel)
        Me.Controls.Add(Me.IndustryAvgSizeTextBox)
        Me.Controls.Add(IndustryAvgSnowLabel)
        Me.Controls.Add(Me.IndustryAvgSnowTextBox)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblCount)
        Me.Controls.Add(RegionIDLabel)
        Me.Controls.Add(Me.RegionIDComboBox)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CustomerHistoryDataGridView)
        Me.Controls.Add(ResortIDLabel)
        Me.Controls.Add(Me.ResortIDTextBox)
        Me.Controls.Add(ResortNameLabel)
        Me.Controls.Add(Me.ResortNameTextBox)
        Me.Controls.Add(ResortAvgAnnualSnowfallLabel)
        Me.Controls.Add(ResortSizeLabel)
        Me.Controls.Add(NumberOfLiftsLabel)
        Me.Controls.Add(ResortWebsiteLabel)
        Me.Controls.Add(Me.ResortWebsiteTextBox)
        Me.Controls.Add(Me.ResortBindingNavigator)
        Me.Name = "ResortVisitors"
        Me.Text = "ResortVisitors"
        CType(Me.SkiCorporationDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResortBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResortBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResortBindingNavigator.ResumeLayout(False)
        Me.ResortBindingNavigator.PerformLayout()
        CType(Me.CustomerHistoryBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerHistoryDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerNamesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SkiCorporationDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RegionBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResortBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RegionBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResortBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AvgSnowFallBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AvgSizeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AvgNumVisitorsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents SkiCorporationDataSet As SkiCorporationDataSet
    Friend WithEvents ResortBindingSource As BindingSource
    Friend WithEvents ResortTableAdapter As SkiCorporationDataSetTableAdapters.ResortTableAdapter
    Friend WithEvents TableAdapterManager As SkiCorporationDataSetTableAdapters.TableAdapterManager
    Friend WithEvents ResortBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents ResortBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents ResortIDTextBox As TextBox
    Friend WithEvents ResortNameTextBox As TextBox
    Friend WithEvents ResortWebsiteTextBox As TextBox
    Friend WithEvents CustomerHistoryTableAdapter As SkiCorporationDataSetTableAdapters.CustomerHistoryTableAdapter
    Friend WithEvents CustomerHistoryBindingSource As BindingSource
    Friend WithEvents CustomerHistoryDataGridView As DataGridView
    Friend WithEvents CustomerTableAdapter As SkiCorporationDataSetTableAdapters.CustomerTableAdapter
    Friend WithEvents CustomerBindingSource As BindingSource
    Friend WithEvents SkiCorporationDataSet1 As SkiCorporationDataSet
    Friend WithEvents CustomerNamesBindingSource As BindingSource
    Friend WithEvents CustomerNamesTableAdapter As SkiCorporationDataSetTableAdapters.CustomerNamesTableAdapter
    Friend WithEvents Label1 As Label
    Friend WithEvents RegionIDComboBox As ComboBox
    Friend WithEvents RegionBindingSource As BindingSource
    Friend WithEvents RegionTableAdapter As SkiCorporationDataSetTableAdapters.RegionTableAdapter
    Friend WithEvents lblCount As Label
    Friend WithEvents ResortBindingSource1 As BindingSource
    Friend WithEvents RegionBindingSource1 As BindingSource
    Friend WithEvents Label2 As Label
    Friend WithEvents ResortBindingSource2 As BindingSource
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents AvgSnowFallBindingSource As BindingSource
    Friend WithEvents AvgSnowFallTableAdapter As SkiCorporationDataSetTableAdapters.AvgSnowFallTableAdapter
    Friend WithEvents IndustryAvgSnowTextBox As TextBox
    Friend WithEvents AvgSizeBindingSource As BindingSource
    Friend WithEvents AvgSizeTableAdapter As SkiCorporationDataSetTableAdapters.AvgSizeTableAdapter
    Friend WithEvents IndustryAvgSizeTextBox As TextBox
    Friend WithEvents AvgNumVisitorsBindingSource As BindingSource
    Friend WithEvents AvgNumVisitorsTableAdapter As SkiCorporationDataSetTableAdapters.AvgNumVisitorsTableAdapter
    Friend WithEvents IndustryAvgVisitorsTextBox As TextBox
    Friend WithEvents lblResortAnalysis As Label
    Friend WithEvents btnResAnalysis As Button
    Friend WithEvents lblAvgDuration As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents AttenDuration As DataGridViewTextBoxColumn
    Friend WithEvents AvgSnowMaskedTextBox As MaskedTextBox
    Friend WithEvents SizeMaskedTextBox As MaskedTextBox
    Friend WithEvents LiftsMaskedTextBox As MaskedTextBox
    Friend WithEvents btnExit As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FormsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CustomersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RegionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResortVisitorsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SearchResortsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SkiCorporationWebsiteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReadMeFileToolStripMenuItem As ToolStripMenuItem
End Class
