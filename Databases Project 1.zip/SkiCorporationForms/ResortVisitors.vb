﻿Public Class ResortVisitors
    Private Sub ResortBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles ResortBindingNavigatorSaveItem.Click
        Try
            Me.Validate()
            Me.ResortBindingSource.EndEdit()
            Me.TableAdapterManager.UpdateAll(Me.SkiCorporationDataSet)
            CalcTotals()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub ResortVisitors_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'SkiCorporationDataSet.AvgNumVisitors' table. You can move, or remove it, as needed.
        Me.AvgNumVisitorsTableAdapter.Fill(Me.SkiCorporationDataSet.AvgNumVisitors)
        'TODO: This line of code loads data into the 'SkiCorporationDataSet.AvgSize' table. You can move, or remove it, as needed.
        Me.AvgSizeTableAdapter.Fill(Me.SkiCorporationDataSet.AvgSize)
        'TODO: This line of code loads data into the 'SkiCorporationDataSet.AvgSnowFall' table. You can move, or remove it, as needed.
        Me.AvgSnowFallTableAdapter.Fill(Me.SkiCorporationDataSet.AvgSnowFall)
        'TODO: This line of code loads data into the 'SkiCorporationDataSet._Region' table. You can move, or remove it, as needed.
        Me.RegionTableAdapter.Fill(Me.SkiCorporationDataSet._Region)
        'TODO: This line of code loads data into the 'SkiCorporationDataSet1.CustomerNames' table. You can move, or remove it, as needed.
        Me.CustomerNamesTableAdapter.Fill(Me.SkiCorporationDataSet1.CustomerNames)
        'TODO: This line of code loads data into the 'SkiCorporationDataSet.Customer' table. You can move, or remove it, as needed.
        Me.CustomerTableAdapter.Fill(Me.SkiCorporationDataSet.Customer)
        'TODO: This line of code loads data into the 'SkiCorporationDataSet.CustomerHistory' table. You can move, or remove it, as needed.
        Me.CustomerHistoryTableAdapter.Fill(Me.SkiCorporationDataSet.CustomerHistory)
        'TODO: This line of code loads data into the 'SkiCorporationDataSet.Resort' table. You can move, or remove it, as needed.
        Me.ResortTableAdapter.Fill(Me.SkiCorporationDataSet.Resort)
        '  Try
        ' ResortAnalysis() ', txtResortSnow.Text)
        'Catch ex As Exception
        'MsgBox(ex.Message)
        'End Try
        CalcTotals()
    End Sub

    Private Sub BindingNavigatorMoveNextItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorMoveNextItem.Click
        CalcTotals()
    End Sub

    Private Sub CalcTotals()
        Dim count As Integer
        Dim AvgDuration As Decimal
        Dim SumDuration As Decimal

        Dim dgvr As System.Windows.Forms.DataGridViewRow
        For Each dgvr In Me.CustomerHistoryDataGridView.Rows
            SumDuration += dgvr.Cells("AttenDuration").Value
        Next dgvr

        count = Me.CustomerHistoryDataGridView.Rows.Count - 1
        lblCount.Text = count.ToString
        If count > 0 Then
            AvgDuration = SumDuration / count
        Else
            lblResortAnalysis.Text = " "
        End If
        lblAvgDuration.Text = AvgDuration.ToString("###.#0")


    End Sub


    Private Sub btnResAnalysis_Click(sender As Object, e As EventArgs) Handles btnResAnalysis.Click 'ByVal size As String) ', ByVal snow As String) ', ByVal visitors As String) As String
        If CType(SizeMaskedTextBox.Text, Integer) > CType(IndustryAvgSizeTextBox.Text, Integer) And CType(AvgSnowMaskedTextBox.Text, Integer) > CType(IndustryAvgSnowTextBox.Text, Integer) And CType(lblCount.Text, Integer) > CType(IndustryAvgVisitorsTextBox.Text, Integer) Then
            lblResortAnalysis.Text = "Tier One: All three of resort's key characteristics exceed national average."
            lblResortAnalysis.BackColor = Color.LawnGreen
        ElseIf CType(SizeMaskedTextBox.Text, Integer) > CType(IndustryAvgSizeTextBox.Text, Integer) Or CType(AvgSnowMaskedTextBox.Text, Integer) > CType(IndustryAvgSnowTextBox.Text, Integer) Then 'Or CType(lblCount.Text, Integer) > CType(IndustryAvgVisitorsTextBox.Text, Integer) Then
            lblResortAnalysis.Text = "Tier Two: One or more of resort's key characteristics are better than national average."
            lblResortAnalysis.BackColor = Color.Yellow
        Else
            lblResortAnalysis.Text = "Lower Tier: All of resort's key characteristics fall below national average."
            lblResortAnalysis.BackColor = Color.Red
        End If
    End Sub
    Dim IsAdding As Boolean = False

    Private Sub BindingNavigatorAddNewItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorAddNewItem.Click
        IsAdding = True
    End Sub

    Private Sub ResortBindingSource_CurrentItemChanged(sender As Object, e As EventArgs) Handles ResortBindingSource.CurrentItemChanged
        If (IsAdding) Then
            Try
                Dim cmd As New Data.SqlClient.SqlCommand
                cmd.CommandText = "SELECT Max(ResortID) AS MaxID FROM [Resort]"
                cmd.CommandType = CommandType.Text
                cmd.Connection = Me.ResortTableAdapter.Connection
                Dim i As Integer
                cmd.Connection.Open()
                i = cmd.ExecuteScalar() + 1
                cmd.Connection.Close()
                Me.ResortIDTextBox.Text = i.ToString
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub ResortBindingSource_PositionChanged(sender As Object, e As EventArgs) Handles ResortBindingSource.PositionChanged
        CalcTotals()
        lblResortAnalysis.Text = " "
        lblResortAnalysis.BackColor = Color.Transparent

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
    Private Sub CustomersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CustomersToolStripMenuItem.Click
        Try
            Dim frmCustomers As New Customers
            frmCustomers.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub RegionToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegionToolStripMenuItem.Click
        Try
            Dim frmRegion As New Region
            frmRegion.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ResortVisitorsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResortVisitorsToolStripMenuItem.Click
        Try
            Dim frmResortVisitors As New ResortVisitors
            frmResortVisitors.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub SearchResortsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchResortsToolStripMenuItem.Click
        Try
            Dim frmSearch As New SearchResorts
            frmSearch.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub ReadMeFileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ReadMeFileToolStripMenuItem.Click
        Try
            Dim frmReadMe As New ReadMe
            frmReadMe.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class