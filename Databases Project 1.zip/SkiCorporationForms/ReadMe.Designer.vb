﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ReadMe
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ReadMe))
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FormsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResortVisitorsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchResortsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SkiCorporationWebsiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReadMeFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(32, 70)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(739, 363)
        Me.RichTextBox1.TabIndex = 0
        Me.RichTextBox1.Text = resources.GetString("RichTextBox1.Text")
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(322, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(130, 31)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Read Me"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(696, 35)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Exit"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FormsToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 28)
        Me.MenuStrip1.TabIndex = 42
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FormsToolStripMenuItem
        '
        Me.FormsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomersToolStripMenuItem, Me.RegionToolStripMenuItem, Me.ResortVisitorsToolStripMenuItem, Me.SearchResortsToolStripMenuItem})
        Me.FormsToolStripMenuItem.Name = "FormsToolStripMenuItem"
        Me.FormsToolStripMenuItem.Size = New System.Drawing.Size(63, 24)
        Me.FormsToolStripMenuItem.Text = "Forms"
        '
        'CustomersToolStripMenuItem
        '
        Me.CustomersToolStripMenuItem.Name = "CustomersToolStripMenuItem"
        Me.CustomersToolStripMenuItem.Size = New System.Drawing.Size(188, 26)
        Me.CustomersToolStripMenuItem.Text = "Customers"
        '
        'RegionToolStripMenuItem
        '
        Me.RegionToolStripMenuItem.Name = "RegionToolStripMenuItem"
        Me.RegionToolStripMenuItem.Size = New System.Drawing.Size(188, 26)
        Me.RegionToolStripMenuItem.Text = "Region"
        '
        'ResortVisitorsToolStripMenuItem
        '
        Me.ResortVisitorsToolStripMenuItem.Name = "ResortVisitorsToolStripMenuItem"
        Me.ResortVisitorsToolStripMenuItem.Size = New System.Drawing.Size(188, 26)
        Me.ResortVisitorsToolStripMenuItem.Text = "Resort Visitors"
        '
        'SearchResortsToolStripMenuItem
        '
        Me.SearchResortsToolStripMenuItem.Name = "SearchResortsToolStripMenuItem"
        Me.SearchResortsToolStripMenuItem.Size = New System.Drawing.Size(188, 26)
        Me.SearchResortsToolStripMenuItem.Text = "Search Resorts"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SkiCorporationWebsiteToolStripMenuItem, Me.ReadMeFileToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(59, 24)
        Me.HelpToolStripMenuItem.Text = " Help"
        '
        'SkiCorporationWebsiteToolStripMenuItem
        '
        Me.SkiCorporationWebsiteToolStripMenuItem.Name = "SkiCorporationWebsiteToolStripMenuItem"
        Me.SkiCorporationWebsiteToolStripMenuItem.Size = New System.Drawing.Size(252, 26)
        Me.SkiCorporationWebsiteToolStripMenuItem.Text = "Ski Corporation Website"
        '
        'ReadMeFileToolStripMenuItem
        '
        Me.ReadMeFileToolStripMenuItem.Name = "ReadMeFileToolStripMenuItem"
        Me.ReadMeFileToolStripMenuItem.Size = New System.Drawing.Size(252, 26)
        Me.ReadMeFileToolStripMenuItem.Text = "Read Me File"
        '
        'ReadMe
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Name = "ReadMe"
        Me.Text = "ReadMe"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FormsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CustomersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RegionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResortVisitorsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SearchResortsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SkiCorporationWebsiteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReadMeFileToolStripMenuItem As ToolStripMenuItem
End Class
