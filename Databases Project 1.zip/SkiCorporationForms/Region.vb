﻿Public Class Region
    Private Sub RegionBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles RegionBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.RegionBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.SkiCorporationDataSet)

    End Sub

    Private Sub Region_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'SkiCorporationDataSet._Region' table. You can move, or remove it, as needed.
        Me.RegionTableAdapter.Fill(Me.SkiCorporationDataSet._Region)

    End Sub

    Private Sub FillByToolStripButton_Click(sender As Object, e As EventArgs) Handles FillByToolStripButton.Click
        Try
            Me.RegionTableAdapter.FillBy(Me.SkiCorporationDataSet._Region, RegionNameToolStripTextBox.Text)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
        Dim n As Integer
        n = Me.RegionDataGridView.Rows.Count - 1
        If n = 0 Then
            MsgBox("No Regions found!")
        End If
    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        Try
            Me.RegionTableAdapter.Fill(Me.SkiCorporationDataSet._Region)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
        RegionNameToolStripTextBox.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class